/**
 * Хук загрузки данных: локальный JSON (по умолчанию) или Google Таблицы.
 */
"use client";

import { useEffect, useMemo, useState } from "react";
import localDatabases from "@/data/databases.json";
import { SITE_CONFIG, type DataItem, type DatabaseKey } from "@/data/site-config";
import { csvToItems } from "@/lib/csv";

export type Databases = Partial<Record<DatabaseKey, DataItem[]>>;

export type DatabaseStatus = "loading" | "ready" | "error";

let cache: Databases | null = null;

async function loadGoogleSheets(): Promise<Databases> {
  const cfg = SITE_CONFIG.googleSheets;
  const results = await Promise.all(
    cfg.databases.map(async (db) => {
      try {
        const url = `https://docs.google.com/spreadsheets/d/e/${cfg.spreadsheetKey}/pub?gid=${db.gid}&single=true&output=csv`;
        const res = await fetch(url);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const text = await res.text();
        return [db.database, csvToItems(text)] as const;
      } catch (e) {
        console.error(`Не удалось загрузить таблицу ${db.database}:`, e);
        return [db.database, [] as DataItem[]] as const;
      }
    })
  );
  return Object.fromEntries(results) as Databases;
}

export function useDatabases() {
  // Локальный JSON доступен синхронно — состояние сразу "ready".
  // Для Google Sheets начальное состояние — "loading".
  const [data, setData] = useState<Databases | null>(() => {
    if (cache) return cache;
    return SITE_CONFIG.googleSheets.enabled ? null : (localDatabases as Databases);
  });
  const [status, setStatus] = useState<DatabaseStatus>(() =>
    cache || !SITE_CONFIG.googleSheets.enabled ? "ready" : "loading"
  );
  const [error, setError] = useState<string | null>(null);

  // Загрузка нужна только для Google Sheets
  useEffect(() => {
    if (!SITE_CONFIG.googleSheets.enabled || cache) return;
    let cancelled = false;

    const load = async () => {
      try {
        const loaded = await loadGoogleSheets();
        if (cancelled) return;
        cache = loaded;
        setData(loaded);
        setStatus("ready");
      } catch (e) {
        if (cancelled) return;
        console.error("Ошибка загрузки данных:", e);
        setError(e instanceof Error ? e.message : "Неизвестная ошибка");
        setStatus("error");
      }
    };
    load();
    return () => {
      cancelled = true;
    };
  }, []);

  const databases = useMemo(() => data ?? {}, [data]);

  const getDatabase = (key: DatabaseKey): DataItem[] => databases[key] ?? [];

  const count = (...keys: DatabaseKey[]) =>
    keys.reduce((sum, k) => sum + (databases[k]?.length ?? 0), 0);

  /** Плоский список всех записей для глобального поиска */
  const allItems = useMemo(() => {
    const sections: { key: DatabaseKey; section: string }[] = [
      { key: "cinfo_aphin", section: "Custom-Info" },
      { key: "cinfo_burst173", section: "Custom-Info" },
      { key: "cinfo_solosquad2008", section: "Custom-Info" },
      { key: "cassie_aphin", section: "C.A.S.S.I.E" },
      { key: "cassie_dev1lmachine", section: "C.A.S.S.I.E" },
      { key: "cassie_burst173", section: "C.A.S.S.I.E" },
      { key: "keycards_burst173", section: "Ключ-карты" },
      { key: "keycards_solosquad2008", section: "Ключ-карты" },
    ];
    return sections.flatMap(({ key, section }) =>
      (databases[key] ?? []).map((item) => ({ ...item, db: key, section }))
    );
  }, [databases]);

  return { databases, getDatabase, count, allItems, status, error };
}
