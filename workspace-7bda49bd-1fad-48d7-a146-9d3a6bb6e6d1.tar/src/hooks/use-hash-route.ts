"use client";

/**
 * Простой hash-роутер (как в оригинале: /#/, /#/cinfo, /#/cassie ...)
 * Работает на GitHub Pages без серверной части.
 * Использует useSyncExternalStore — корректно для SSR и React 19.
 */
import { useCallback, useSyncExternalStore } from "react";

export type Route = "/" | "/cinfo" | "/cassie" | "/keycards" | "/information" | "/history";

export const ROUTES: Route[] = ["/", "/cinfo", "/cassie", "/keycards", "/information", "/history"];

function parseHash(): Route {
  const hash = window.location.hash.replace(/^#/, "");
  const path = hash.split("?")[0] || "/";
  const normalized = (path.endsWith("/") && path !== "/" ? path.slice(0, -1) : path) as Route;
  return ROUTES.includes(normalized) ? normalized : "/";
}

function subscribe(callback: () => void) {
  window.addEventListener("hashchange", callback);
  return () => window.removeEventListener("hashchange", callback);
}

function getSnapshot(): Route {
  return parseHash();
}

function getServerSnapshot(): Route {
  return "/";
}

export function useHashRoute() {
  const route = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);

  const navigate = useCallback((to: Route) => {
    window.location.hash = to === "/" ? "/" : to;
  }, []);

  return { route, navigate };
}
