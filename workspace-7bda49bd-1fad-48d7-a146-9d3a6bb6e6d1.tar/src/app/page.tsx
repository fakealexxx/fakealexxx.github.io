"use client";

/**
 * Точка входа сайта LITERY | Events.
 * SPA с hash-роутингом (как в оригинале): /#/, /#/cinfo, /#/cassie ...
 */
import React, { useCallback, useState } from "react";
import { TOCProvider } from "@/components/site/toc-context";
import { TerminalLayout } from "@/components/site/terminal-layout";
import { SearchDialog } from "@/components/site/search-dialog";
import { HomePage } from "@/components/site/home-page";
import { CinfoPage } from "@/components/site/cinfo-page";
import { CassiePage } from "@/components/site/cassie-page";
import { KeycardsPage } from "@/components/site/keycards-page";
import { InformationPage } from "@/components/site/information-page";
import { HistoryPage } from "@/components/site/history-page";
import { useHashRoute, type Route } from "@/hooks/use-hash-route";

export default function Home() {
  const { route } = useHashRoute();
  const [searchOpen, setSearchOpen] = useState(false);

  const navigate = useCallback((to: Route) => {
    window.location.hash = to === "/" ? "/" : to;
  }, []);

  const renderPage = () => {
    switch (route) {
      case "/cinfo":
        return <CinfoPage />;
      case "/cassie":
        return <CassiePage />;
      case "/keycards":
        return <KeycardsPage />;
      case "/information":
        return <InformationPage />;
      case "/history":
        return <HistoryPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <TOCProvider>
      <TerminalLayout route={route} onOpenSearch={() => setSearchOpen(true)}>
        {renderPage()}
      </TerminalLayout>
      <SearchDialog open={searchOpen} onOpenChange={setSearchOpen} onNavigate={navigate} />
    </TOCProvider>
  );
}
