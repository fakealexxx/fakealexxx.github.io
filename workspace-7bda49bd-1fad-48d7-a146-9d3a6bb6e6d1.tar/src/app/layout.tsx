import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { SITE_CONFIG } from "@/data/site-config";

const inter = Inter({
  variable: "--font-geist-sans",
  subsets: ["latin", "cyrillic"],
});

export const metadata: Metadata = {
  title: SITE_CONFIG.title,
  description:
    "Терминал ивент-мастера: Custom-Info, C.A.S.S.I.E, ключ-карты и полезная информация для SCP: Secret Laboratory.",
  keywords: ["SCP", "SCP:SL", "ивенты", "C.A.S.S.I.E", "Custom-Info", "ключ-карты"],
  icons: {
    icon: "/images/litery.png",
  },
};

export const viewport: Viewport = {
  themeColor: "#0a0a0a",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru" suppressHydrationWarning>
      <body
        className={`${inter.variable} antialiased bg-scp-bg text-zinc-200`}
      >
        {children}
        <Toaster />
        <SonnerToaster
          position="bottom-right"
          toastOptions={{
            classNames: {
              toast: "bg-zinc-900 border-zinc-800 text-zinc-200",
              description: "text-zinc-400",
            },
          }}
        />
      </body>
    </html>
  );
}
