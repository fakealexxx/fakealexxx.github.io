"use client";

/**
 * Загружает базу данных по ключу и отрисовывает аккордеон с копированием.
 */
import React, { useEffect } from "react";
import { AccordionCopy } from "./accordion-copy";
import { useDatabases } from "@/hooks/use-databases";
import { useTOCRefresh } from "./toc-context";
import type { DatabaseKey } from "@/data/site-config";

export function DatabaseSection({
  databaseName,
  searchPlaceholder,
}: {
  databaseName: DatabaseKey;
  searchPlaceholder?: string;
}) {
  const { refreshTOC } = useTOCRefresh();
  const { getDatabase, status, error } = useDatabases();

  useEffect(() => {
    if (status === "ready" && !error) {
      setTimeout(() => refreshTOC(), 100);
    }
  }, [status, error, databaseName, refreshTOC]);

  if (status === "loading") {
    return (
      <div className="flex flex-col items-center justify-center gap-4 py-16">
        <div className="w-8 h-8 border-2 border-scp-orange border-t-transparent rounded-full animate-spin" />
        <div className="text-lg sm:text-xl text-scp-orange font-black uppercase tracking-widest">
          Загрузка информации
        </div>
      </div>
    );
  }

  if (status === "error") {
    return <div className="text-red-500 font-bold uppercase tracking-widest text-sm">Ошибка загрузки данных.</div>;
  }

  const items = getDatabase(databaseName);
  if (!items.length) {
    return (
      <div className="text-zinc-500 text-sm uppercase tracking-widest">
        Записи не найдены.
      </div>
    );
  }

  return <AccordionCopy items={items} searchPlaceholder={searchPlaceholder} />;
}
