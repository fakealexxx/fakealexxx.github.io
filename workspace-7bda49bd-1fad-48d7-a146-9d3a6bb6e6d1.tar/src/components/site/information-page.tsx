"use client";

/**
 * Страница «Полезная информация» — гайды: Custom-Info (теги, цвета, ошибки),
 * Строительство (ProjectMER: ToolGun, команды mp, свойства объектов),
 * Прочее (ccolor, intercomtext, команды, ID классов).
 * Контент перенесён с оригинальной страницы Information.
 */
import React from "react";
import { Check, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { withBasePath } from "@/lib/base-path";
import { PageHeader, InfoSectionCenter, Code, Group, CommandTable } from "./shared";
import { useTOC } from "./toc-context";

/* ------------------------------------------------------------------ */
/*  Локальные помощники оформления                                     */
/* ------------------------------------------------------------------ */

/** Разделитель внутри секции */
function Divider() {
  return <div className="h-px bg-scp-orange/20 my-2" aria-hidden="true" />;
}

/** Вложенная панель внутри большой секции */
function Panel({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={cn("rounded-xl border border-zinc-800 bg-zinc-900/40 p-4 sm:p-6 relative overflow-hidden", className)}>
      {children}
    </div>
  );
}

/** Заголовок панели (h3 — попадает в оглавление, если передан toc) */
function PanelTitle({ children, toc }: { children: React.ReactNode; toc?: string }) {
  return (
    <h3
      data-toc={toc}
      className="text-lg sm:text-xl font-black uppercase tracking-widest text-white border-l-2 border-scp-orange pl-3"
    >
      {children}
    </h3>
  );
}

/** Блок с командой (моноширинный, как консоль) */
function CmdBlock({ children }: { children: React.ReactNode }) {
  return (
    <div className="w-fit max-w-full bg-zinc-800 border border-zinc-700/50 rounded-lg px-4 py-2.5 font-mono text-[15px] text-zinc-100 break-all">
      {children}
    </div>
  );
}

/** Строка значения свойства: код-чип + описание */
function Val({ code, text }: { code: string; text?: string }) {
  return (
    <div className="leading-relaxed">
      <Code>{code}</Code>
      {text && <span className="text-zinc-400"> — {text}</span>}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Таблица свойств объекта (свойство | описание | значения)           */
/* ------------------------------------------------------------------ */

type PropCols = [number, number, number];

/** Статическая карта классов колонок (Tailwind требует литеральные классы) */
const PROP_COL_MAP: Record<string, [string, string, string]> = {
  "2-6-4": ["sm:col-span-2", "sm:col-span-6", "sm:col-span-4"],
  "2-5-5": ["sm:col-span-2", "sm:col-span-5", "sm:col-span-5"],
  "2-4-6": ["sm:col-span-2", "sm:col-span-4", "sm:col-span-6"],
  "2-3-7": ["sm:col-span-2", "sm:col-span-3", "sm:col-span-7"],
  "2-2-8": ["sm:col-span-2", "sm:col-span-2", "sm:col-span-8"],
};

interface PropRow {
  name: React.ReactNode;
  desc: React.ReactNode;
  values: React.ReactNode;
  cols?: PropCols;
}

function PropertyTable({ rows, cols = [2, 6, 4] }: { rows: PropRow[]; cols?: PropCols }) {
  return (
    <div className="border border-zinc-800 rounded-lg overflow-hidden mt-4">
      {rows.map((row, i) => {
        const c = row.cols ?? cols;
        const cls = PROP_COL_MAP[`${c[0]}-${c[1]}-${c[2]}`] ?? PROP_COL_MAP["2-6-4"];
        return (
          <div key={i} className={cn("grid grid-cols-12", i < rows.length - 1 && "border-b border-zinc-800")}>
            <div
              className={cn(
                "col-span-12 p-3 flex items-center justify-center text-center border-b sm:border-b-0 sm:border-r border-zinc-800 bg-zinc-950/40",
                cls[0]
              )}
            >
              {row.name}
            </div>
            <div className={cn("col-span-12 p-3 flex items-center border-b sm:border-b-0 border-zinc-800", cls[1])}>
              {row.desc}
            </div>
            <div className={cn("col-span-12 p-3 space-y-1.5 text-sm", cls[2])}>{row.values}</div>
          </div>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Данные                                                             */
/* ------------------------------------------------------------------ */

/** Теги Custom-Info */
const CI_TAGS: { tag: string; label: string; accent?: boolean }[] = [
  { tag: "<size>", label: "размер" },
  { tag: "<b>", label: "жирность" },
  { tag: "<i>", label: "курсив" },
  { tag: "<color>", label: "цвет", accent: true },
];

/** Доступные цвета Custom-Info */
const CUSTOM_COLORS: { name: string; hex: string }[] = [
  { name: "pink", hex: "#FF96DE" },
  { name: "red", hex: "#C50000" },
  { name: "default", hex: "#FFFFFF" },
  { name: "brown", hex: "#944710" },
  { name: "silver", hex: "#A0A0A0" },
  { name: "light_green", hex: "#32CD32" },
  { name: "crimson", hex: "#DC143C" },
  { name: "cyan", hex: "#00B7EB" },
  { name: "aqua", hex: "#00FFFF" },
  { name: "deep_pink", hex: "#FF1493" },
  { name: "tomato", hex: "#FF6448" },
  { name: "yellow", hex: "#FAFF86" },
  { name: "magenta", hex: "#FF0090" },
  { name: "blue_green", hex: "#4DFFB8" },
  { name: "orange", hex: "#FF9966" },
  { name: "lime", hex: "#BFFF00" },
  { name: "green", hex: "#228B22" },
  { name: "emerald", hex: "#50C878" },
  { name: "carmine", hex: "#960018" },
  { name: "nickel", hex: "#727472" },
  { name: "mint", hex: "#98FB98" },
  { name: "army_green", hex: "#4B5320" },
  { name: "pumpkin", hex: "#EE7600" },
];

/** Объекты ProjectMER (mp create) */
const MER_OBJECTS = [
  "1 - Красный примитив 1х1х1",
  "2 - Источник освещения",
  "3 - Дверь",
  "4 - Стол модификации оружия",
  "5 - Точка спавна предметов",
  "6 - Точка спавна игроков",
  "7 - Капибара",
  "8 - Текст",
  "9 - Камера SCP-079 (функциональна)",
  "10 - Мишень для стрельбы",
  "11 - Все виды шкафчиков",
  "12 - Телепорт",
];

/** ID классов */
const CLASS_ROLES: [string, string][] = [
  ["spectator", "Наблюдатель"],
  ["overwatch", "Надзиратель"],
  ["filmmaker", "Режиссер"],
  ["tutorial", "Обучение"],
  ["classd", "Д-класс"],
  ["facilityguard", "Сотрудник безопасности"],
  ["scientist", "Научный сотрудник"],
  ["chaosrepressor", "Усмиритель ПХ"],
  ["chaosmarauder", "Мародёр ПХ"],
  ["chaosrifleman", "Стрелок ПХ"],
  ["chaosconscript", "Новобранец ПХ"],
  ["ntfprivate", "Рядовой МОГ"],
  ["ntfsergeant", "Сержант МОГ"],
  ["ntfcaptain", "Капитан МОГ"],
  ["ntfspecialist", "Специалист МОГ"],
  ["scp049", "SCP-049"],
  ["scp3114", "SCP-3114"],
  ["scp939", "SCP-939"],
  ["scp079", "SCP-079"],
  ["scp0492", "SCP-049-2"],
  ["scp096", "SCP-096"],
  ["scp106", "SCP-106"],
  ["scp173", "SCP-173"],
];

const CLASS_ABBREVS: [string, string][] = [
  ["tut", "Обучение"],
  ["sci", "Научный сотрудник"],
  ["cld", "Д-класс"],
];

const CLASS_COMMANDS: [string, string][] = [
  ["ci", "Повстанцы Хаоса"],
  ["mtf", "МОГ"],
  ["scp", "SCP"],
  ["alive", "Все живые игроки"],
  ["rip", "Все игроки в Наблюдателях и Надзирателях"],
  ["civilian", "Научные сотрудники и Д-класс"],
  ["military", "Оперативники МОГ, Повстанцы Хаоса, Служба безопасности"],
  ["staff", "Весь персонал фонда"],
  ["nostaff", "Все, кто не относится к персоналу"],
  ["all", "Все"],
  ["*", "То же самое что и all"],
];

/* ------------------------------------------------------------------ */
/*  Страница                                                           */
/* ------------------------------------------------------------------ */

export function InformationPage() {
  useTOC(true);

  return (
    <div className="space-y-10 pb-24">
      <PageHeader
        title="Полезная "
        highlight="информация"
        description="Используйте оглавление слева для более удобной навигации"
      />

      {/* ============================== Custom-Info ============================== */}
      <InfoSectionCenter title="Custom-Info" id="custom-info">
        <div className="space-y-5 text-[15px] sm:text-base">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {CI_TAGS.map((t) => (
              <div
                key={t.tag}
                className="flex flex-col items-center gap-2 rounded-xl border border-zinc-800 bg-zinc-900/40 p-4 text-center"
              >
                <Code>{t.accent ? <span className="text-scp-orange">{t.tag}</span> : t.tag}</Code>
                <span className="italic text-zinc-500 text-sm">{t.label}</span>
              </div>
            ))}
          </div>

          <Divider />

          <div>
            <h3
              data-toc="Примечания"
              className="text-lg font-black uppercase tracking-widest text-white border-l-2 border-scp-orange pl-3"
            >
              Примечания
            </h3>
            <ul className="list-disc list-outside pl-5 pt-4 space-y-2">
              <li>
                Максимальная длина текста в Custom-Info равна <Code>400</Code> символам.
              </li>
              <li>Теги пишутся вместе с текстом и не видны при правильном написании.</li>
              <li>
                Для каждого тега обязательно должен быть закрывающий тег: <Code>{"</тэг>"}</Code>.
              </li>
            </ul>
          </div>

          <Panel>
            <PanelTitle toc="Цвет">Цвет</PanelTitle>
            <p className="mt-4">
              Цвета обязательно должны быть в формате HEX (<Code>#FFFFFF</Code>) и обязательно из списка доступных
              цветов.{" "}
              <span className="text-red-500">
                Также очень важно: буквы в коде цвета должны быть заглавные, иначе будет ошибка.
              </span>
            </p>
            <div className="mt-4">
              <Group title="Цвета" header={false} defaultOpen>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                  {CUSTOM_COLORS.map((c) => (
                    <div
                      key={c.name}
                      className="flex items-center gap-2 bg-zinc-900/60 border border-zinc-800 rounded-lg px-2.5 py-1.5"
                    >
                      <span
                        className="w-4 h-4 rounded-sm border border-zinc-600 shrink-0"
                        style={{ backgroundColor: c.hex }}
                        aria-hidden="true"
                      />
                      <Code>{c.name}</Code>
                      <span className="ml-auto font-mono text-[11px] text-zinc-500">{c.hex}</span>
                    </div>
                  ))}
                </div>
              </Group>
            </div>
          </Panel>

          <Panel>
            <PanelTitle toc="Проблемы">Проблемы</PanelTitle>
            <p className="mt-4">
              Все ошибки, связанные с Custom-Info, выводятся в клиентскую консоль (консоль на букву Ё), но туда
              выводятся вообще все ошибки сервера. Например, если несколько человек в одно время устанавливают
              неправильное custom info, то можно перепутать ошибки.
            </p>
            <ul className="space-y-3 mt-4">
              <li>
                <Code>Provided text has rich text tag which is not allowed</Code> — вы использовали какой-то{" "}
                <Code>{"<тег>"}</Code>, который использовать нельзя.
              </li>
              <li>
                <Code>Provided text doesn&apos;t match the PlayerCustomInfo regex</Code> — превышено допустимое
                количество символов, равное <Code>400</Code>, либо у вас есть лишние закрывающие или открывающие теги.
              </li>
              <li>
                <Code>Provided color tag doesn&apos;t match the requirements - Invalid color</Code> — цвет, который вы
                написали в <Code>{"<color>"}</Code>, написан неправильно.
              </li>
              <li>
                <Code>Provided color tag doesn&apos;t match the requirements - This color is not from allowed list</Code>{" "}
                — цвета, который вы написали в <Code>{"<color>"}</Code>, нет в списке доступных цветов.
              </li>
            </ul>
          </Panel>
        </div>
      </InfoSectionCenter>

      {/* ========================= Строительство (ProjectMER) ========================= */}
      <InfoSectionCenter title="Строительство (ProjectMER)" id="projectmer">
        <div className="space-y-5 text-[15px] sm:text-base">
          <p>
            С ProjectMER вам доступно продвинутое редактирование карты и создание сложных построек. Для этого в плагине
            есть множество инструментов. Вы можете увидеть все команды, написав в RemoteAdmin панель команду{" "}
            <Code>mp</Code>. Почти все команды имеют альтернативное, сокращённое написание. В тексте будет приведено
            лишь основное написание команды.
          </p>
          <p>
            <span className="text-red-500 font-bold">Важно!</span> Ни в одной из команд не нужно писать{" "}
            <Code>``</Code>.
          </p>

          {/* ---------- ToolGun ---------- */}
          <Panel>
            <PanelTitle toc="ToolGun">ToolGun</PanelTitle>
            <div className="grid lg:grid-cols-2 gap-6 mt-5 items-start">
              <div className="flex flex-col gap-2">
                <img
                  src={withBasePath("/images/toolgun.png")}
                  alt="Интерфейс ToolGun с информацией об объекте внизу экрана"
                  loading="lazy"
                  className="rounded-xl hover:scale-105 transition-transform max-w-full h-auto w-full border border-zinc-800"
                />
              </div>
              <div className="space-y-4">
                <p>
                  Тулган выдается командой <Code>mp toolgun</Code> или сокращенно <Code>mp tg</Code>. С его помощью
                  можно создавать примитивы, двери, источники освещения и т.д. Внизу экрана можно увидеть основную
                  информацию об объекте, который вы создаете (см. скриншот).
                </p>
                <p className="font-bold text-zinc-200">Управление:</p>
                <CommandTable
                  colsFirst={2}
                  rows={[
                    { cmd: "R", text: "Переключение влево" },
                    { cmd: "T", text: "Переключение вправо" },
                    { cmd: "F", text: "Переключение режима установка/удаление" },
                    { cmd: "ПКМ", text: "Режим выделения" },
                    { cmd: "ЛКМ", text: "Установка/удаление объекта" },
                  ]}
                />
                <p className="text-sm text-zinc-500">
                  Также если у вас переназначены клавиши перезарядки, выбрасывания предмета, фонарика на оружии и
                  прицеливания, то используйте ваши клавиши вместо приведенных выше.
                </p>
              </div>
            </div>
          </Panel>

          {/* ---------- Взаимодействие с картой и объектами ---------- */}
          <Panel>
            <PanelTitle toc="Взаимодействие с картой и объектами">Взаимодействие с картой и объектами</PanelTitle>
            <p className="mt-4">В ProjectMER есть два типа построек:</p>
            <div className="border border-zinc-800 rounded-lg overflow-hidden mt-4">
              {[
                {
                  name: "Схематики",
                  desc: "Создаются в Unity, их можно перемещать, вращать, изменять размер.",
                },
                {
                  name: "Карты",
                  desc: "Создаются на самом сервере из уже поставленных схематиков и иных объектов, их нельзя перемещать, вращать, изменять размер.",
                },
              ].map((t, i) => (
                <div key={t.name} className={cn("grid grid-cols-1 sm:grid-cols-3", i === 0 && "border-b border-zinc-800")}>
                  <div className="p-4 flex items-center justify-center text-scp-orange font-bold uppercase tracking-widest text-sm border-b sm:border-b-0 sm:border-r border-zinc-800">
                    {t.name}
                  </div>
                  <div className="p-4 sm:col-span-2 flex items-center">{t.desc}</div>
                </div>
              ))}
            </div>

            <p className="mt-6">
              Взаимодействие с <span className="text-scp-orange">картой</span> ограничено всего четырьмя командами:
            </p>
            <CommandTable
              colsFirst={5}
              rows={[
                { cmd: "mp save `название карты`", text: "Сохранить текущие постройки" },
                { cmd: "mp load `название карты`", text: "Загрузить карту" },
                { cmd: "mp unload", text: "Удалить все загруженные схематики, карты и иные объекты" },
                {
                  cmd: "mp merge `новая карта` `карта 1` `карта 2`",
                  text: "Превратить несколько карт в одну, их количество может быть каким угодно",
                },
              ]}
            />

            <p className="mt-6">
              В свою очередь инструментов для взаимодействия со <span className="text-scp-orange">схематиками</span> и{" "}
              <span className="text-scp-orange">объектами</span> гораздо больше:
            </p>
            <CommandTable
              colsFirst={3}
              rows={[
                { cmd: "mp list", text: "Выводит список всех схематиков и карт" },
                {
                  cmd: "mp indicators",
                  text: "Переключает отображение телепортов, мест спавна игроков, вещей и т.д",
                },
                {
                  cmd: "mp delete `id объекта`",
                  text: (
                    <>
                      Удалить объект на который вы смотрите, или удалить объект с указанным <Code>id</Code>
                    </>
                  ),
                },
                {
                  cmd: "mp select",
                  text: "Выделить объект на который вы смотрите, в случае если у вас уже выделен какой-либо объект и вы смотрите не на другой объект, то вы уберете выделение",
                },
                { cmd: "mp scale set x y z", text: "Добавляет размер к уже существующему размеру" },
                { cmd: "mp scale set x y z", text: "Задает указанный размер" },
                { cmd: "mp position add x y z", text: "Добавляет координаты к уже существующим" },
                { cmd: "mp position set x y z", text: "Задает указанные координаты в этой комнате" },
                { cmd: "mp position bring", text: "Телепортирует схематик к вам" },
                { cmd: "mp position grab", text: "Позволяет «взять» схематик на который вы смотрите" },
                { cmd: "mp rotation add x y z", text: "Добавляет указанное значение к повороту" },
                { cmd: "mp rotation set x y z", text: "Устанавливает указанное значение поворота" },
                {
                  cmd: "mp create `название схематика или номер объекта`",
                  text: "Создать схематик или какой либо объект из списка",
                },
              ]}
            />

            <div className="mt-8">
              <p className="text-center text-lg font-black uppercase tracking-widest text-white">Объекты</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 mt-4">
                {MER_OBJECTS.map((obj) => (
                  <div
                    key={obj}
                    className="text-sm px-3 py-2 bg-zinc-900/60 rounded border border-zinc-800 text-zinc-400 flex items-center justify-center text-center"
                  >
                    {obj}
                  </div>
                ))}
              </div>
            </div>
          </Panel>

          {/* ---------- Свойства объектов ---------- */}
          <Panel>
            <PanelTitle toc="Свойства объектов">Свойства объектов</PanelTitle>
            <p className="mt-4">
              Команда <Code>mp mod</Code> позволяет изменять свойства созданных объектов:
            </p>
            <ul className="list-disc list-outside pl-5 pt-3 space-y-2">
              <li>
                Если просто прописать <Code>mp mod</Code>, то вы получите все свойства выделенного объекта и их
                значения.
              </li>
              <li>
                Узнать возможные значения свойства: <Code>mp mod `название свойства`</Code>
              </li>
              <li>
                Задать свойство объекту: <Code>mp mod `название свойства` `значение свойства`</Code>
              </li>
            </ul>

            <Divider />

            <div className="grid lg:grid-cols-2 gap-6 items-start">
              <div className="flex flex-col items-center gap-3">
                <img
                  src={withBasePath("/images/other3.png")}
                  alt="Список свойств выделенного примитива в ToolGun"
                  loading="lazy"
                  className="rounded-xl hover:scale-105 transition-transform max-w-full h-auto w-full border border-zinc-800"
                />
                <Code>При выделенном «примитиве»</Code>
              </div>
              <div className="space-y-3">
                <h4 className="text-base sm:text-lg font-black uppercase tracking-widest text-white">
                  Свойства всех объектов
                </h4>
                <p>
                  <Code>MapName</Code> — название карты, к которой принадлежит объект.
                </p>
                <p>
                  <Code>ID</Code> — идентификатор объекта.
                </p>
                <p>
                  <Code>Room</Code> — название комнаты, к которой принадлежит объект.
                </p>
                <p>
                  <Code>Index</Code> — позволяет ставить объект в таких же комнатах, изменяя значение этого свойства.
                  Чтобы объект появился в каждой такой же комнате, поставьте значение <Code>-1</Code>: объект будет с
                  такими же свойствами, что и оригинальный, а также будет обновляться при изменении оригинального
                  объекта.
                </p>
              </div>
            </div>

            <Divider />

            <h3
              data-toc="Свойства примитива"
              className="text-lg font-black uppercase tracking-widest text-white border-l-2 border-scp-orange pl-3"
            >
              Свойства примитива
            </h3>
            <PropertyTable
              rows={[
                {
                  name: <Code>PrimitiveType</Code>,
                  desc: "Тип примитива, по умолчанию это Cube. Вводить нужно либо числовое значение, либо буквенное.",
                  values: (
                    <>
                      <Val code="0" text="Sphere" />
                      <Val code="1" text="Capsule" />
                      <Val code="2" text="Cylinder" />
                      <Val code="3" text="Cube" />
                      <Val code="4" text="Plane" />
                      <Val code="5" text="Quad" />
                    </>
                  ),
                },
                {
                  name: <Code>Color</Code>,
                  desc: "Цвет примитива, по умолчанию — красный. Принимает цвет как в формате HEX, так и в формате RGB. У RGB формата больше возможностей: если поставить значения цвета выше 255, а значение прозрачности (последняя цифра) меньше единицы, то получится примитив, который «светится», но не освещает вокруг себя ничего. И чем больше значения — тем ярче светится примитив.",
                  values: (
                    <>
                      <Val code="#ff0000" />
                      <Val code="255:0:0:1" />
                    </>
                  ),
                },
                {
                  name: <Code>PrimitiveFlags</Code>,
                  desc: "Свойства видимости и коллизии объекта. Если вам нужно сделать невидимый барьер, то лучше сделать это через PrimitiveFlags.",
                  values: (
                    <>
                      <Val code="0" text="невидимый и без коллизии" />
                      <Val code="1" text="с коллизией, но невидимый" />
                      <Val code="2" text="без коллизии, но видимый" />
                      <Val code="3" text="видимый и с коллизией" />
                    </>
                  ),
                },
              ]}
            />

            <Divider />

            <h3
              data-toc="Свойства источника света"
              className="text-lg font-black uppercase tracking-widest text-white border-l-2 border-scp-orange pl-3"
            >
              Свойства источника света
            </h3>
            <PropertyTable
              rows={[
                {
                  name: <Code>Color</Code>,
                  desc: "Цвет освещения. Воспринимает цвета в формате HEX.",
                  values: <Val code="1" />,
                },
                {
                  name: <Code>Intensity</Code>,
                  desc: "Яркость освещения",
                  values: <Val code="1" />,
                },
                {
                  name: <Code>Range</Code>,
                  desc: "Дистанция, на которую источник будет светить",
                  values: <Val code="1" />,
                },
                {
                  name: <Code>Shadows</Code>,
                  desc: (
                    <>
                      Качество теней, отбрасываемых объектами от света.{" "}
                      <span className="text-red-500">Крайне не рекомендуется ставить мягкие тени</span>
                    </>
                  ),
                  values: (
                    <>
                      <Val code="None" text="не отбрасывать тени" />
                      <Val code="Hard" text="отбрасывать обычные тени" />
                      <Val code="Soft" text="отбрасывать мягкие тени" />
                    </>
                  ),
                },
                {
                  name: <Code>SpotAngle</Code>,
                  desc: "Угол освещения типом Spot. Не может превышать 179 градусов.",
                  values: <Val code="90" />,
                },
                {
                  name: <Code>LightType</Code>,
                  desc: "Тип освещения",
                  cols: [2, 2, 8],
                  values: (
                    <>
                      <Val code="Spot" text="освещение определенной области, как если бы на нее светил фонарь" />
                      <Val code="Directional" text="освещение всей карты в каком-то направлении" />
                      <Val code="Point" text="освещение из точки, все остальные типы не отличаются от него" />
                    </>
                  ),
                },
              ]}
            />

            <Divider />

            <h3
              data-toc="Свойства двери"
              className="text-lg font-black uppercase tracking-widest text-white border-l-2 border-scp-orange pl-3"
            >
              Свойства двери
            </h3>
            <PropertyTable
              cols={[2, 3, 7]}
              rows={[
                {
                  name: <Code>DoorType</Code>,
                  desc: "Тип двери",
                  values: (
                    <>
                      <Val code="LightContainmentDoor" text="дверь из ЛЗС" />
                      <Val code="Hcz" text="дверь из ТЗС" />
                      <Val code="Ez" text="дверь из входной зоны" />
                      <Val code="Bulkdoor" text="современные гермоворота из ТЗС" />
                      <Val code="Gate" text="устаревшие гермоворота из других зон" />
                    </>
                  ),
                },
                {
                  name: <Code>IsOpen</Code>,
                  desc: "Открыта ли дверь",
                  values: (
                    <>
                      <Val code="False" text="закрыта" />
                      <Val code="True" text="открыта" />
                    </>
                  ),
                },
                {
                  name: <Code>IsOpen</Code>,
                  desc: "Открыта ли дверь",
                  values: (
                    <>
                      <Val code="False" text="закрыта" />
                      <Val code="True" text="открыта" />
                    </>
                  ),
                },
                {
                  name: <Code>IsLocked</Code>,
                  desc: "Заблокирована ли дверь",
                  values: (
                    <>
                      <Val code="False" text="разблокирована" />
                      <Val code="True" text="заблокирована" />
                    </>
                  ),
                },
                {
                  name: <Code>RequiredPermissions</Code>,
                  desc: "Требования к ключ-карте для открытия.",
                  values: (
                    <>
                      <Val code="None" text="не требуется" />
                      <Val code="Checkpoints" text="карты с доступом к КПП" />
                      <Val code="ExitGates" text="карты с доступом к гейтам" />
                      <Val code="Intercom" text="карты с доступом к интеркому" />
                      <Val code="AlphaWarhead" text="карты с доступом к боеголовке" />
                      <Val code="ContainmentLevelOne" text="карты с 1УД к SCP" />
                      <Val code="ContainmentLevelTwo" text="карты со 2УД к SCP" />
                      <Val code="ContainmentLevelThree" text="карты с 3УД к SCP" />
                      <Val code="ArmoryLevelOne" text="карты с 1УД допуска к оружейным" />
                      <Val code="ArmoryLevelTwo" text="карты со 2УД к оружейным" />
                      <Val code="ArmoryLevelThree" text="карты с 3УД к оружейным" />
                      <Val code="ScpOverride" text="доступ только для SCP" />
                    </>
                  ),
                },
                {
                  name: <Code>RequireAll</Code>,
                  desc: "Требуются ли все выше доступы для открытия двери",
                  values: (
                    <>
                      <Val code="False" text="не требуются" />
                      <Val code="True" text="требуются" />
                    </>
                  ),
                },
              ]}
            />

            <Divider />

            <h3
              data-toc="Свойства ItemSpawnpoint"
              className="text-lg font-black uppercase tracking-widest text-white border-l-2 border-scp-orange pl-3"
            >
              Свойства ItemSpawnpoint
            </h3>
            <PropertyTable
              cols={[2, 5, 5]}
              rows={[
                {
                  name: <Code>ItemType</Code>,
                  desc: "Предмет, который будет появляться",
                  values: (
                    <>
                      <div>Принимает текстовый или числовой ID предмета:</div>
                      <Val code="25" />
                      <Val code="GrenadeHE" />
                    </>
                  ),
                },
                {
                  name: <Code>Weight</Code>,
                  desc: "Тяжесть предмета, влияет только на скорость подбора предмета в первый раз",
                  values: <Val code="1" />,
                },
                {
                  name: <Code>AttachmentsCode</Code>,
                  desc: "Влияет на обвесы для оружия",
                  values: <Val code="512" />,
                },
                {
                  name: <Code>NumberOfItems</Code>,
                  desc: "Количество предметов, появляющихся одновременно",
                  values: (
                    <>
                      <Val code="1" />
                      <div className="text-red-500">Значения свыше 100 могут положить сервер</div>
                    </>
                  ),
                },
                {
                  name: <Code>NumberOfUses</Code>,
                  desc: "Сколько раз можно будет подобрать предмет",
                  values: <Val code="1" />,
                },
                {
                  name: <Code>UseGravity</Code>,
                  desc: "Подчиняется ли предмет закону гравитации",
                  values: (
                    <>
                      <Val code="False" text="предмет будто в космосе" />
                      <Val code="True" text="нормальное поведение предмета" />
                    </>
                  ),
                },
                {
                  name: <Code>CanBePickedUp</Code>,
                  desc: "Можно ли поднять предмет",
                  values: (
                    <>
                      <Val code="False" text="нет" />
                      <Val code="True" text="да" />
                    </>
                  ),
                },
              ]}
            />

            <Divider />

            <h3
              data-toc="Свойства Locker"
              className="text-lg font-black uppercase tracking-widest text-white border-l-2 border-scp-orange pl-3"
            >
              Свойства Locker
            </h3>
            <PropertyTable
              rows={[
                {
                  name: <Code>LockerType</Code>,
                  desc: "Тип шкафчика",
                  cols: [2, 2, 8],
                  values: (
                    <>
                      <Val code="PedestalScp`подставьте номер SCP`" text="ящики всех карманных SCP игры" />
                      <Val code="PedestalScpAntiScp207" text="ящик с анти-колой" />
                      <Val code="LargeGun" text="большой, оружейный шкаф" />
                      <Val code="RifleRack" text="контейнер с E11-SR" />
                      <Val code="Misc" text="шкаф с ключ-картами, аптечками, фонариками и т.д." />
                      <Val code="Medkit" text="шкафчик с аптечкой и обезболивающим" />
                      <Val code="Adrenaline" text="шкафчик с аптечкой и адреналином" />
                      <Val code="ExperimentalWeapon" text="контейнер с экспериментальным оружием" />
                      <Val code="None" text="удаляет шкафчик" />
                    </>
                  ),
                },
                {
                  name: (
                    <>
                      <Code>Loot</Code>
                      <br />
                      <Code>Chambers</Code>
                    </>
                  ),
                  desc: "Изменяет заготовленные пресеты вещей в шкафчике",
                  cols: [2, 4, 6],
                  values: (
                    <>
                      <Val code="add ???" />
                      <Val code="remove ???" />
                    </>
                  ),
                },
              ]}
            />

            <Divider />

            <h3
              data-toc="Свойства Teleport"
              className="text-lg font-black uppercase tracking-widest text-white border-l-2 border-scp-orange pl-3"
            >
              Свойства Teleport
            </h3>
            <PropertyTable
              cols={[2, 5, 5]}
              rows={[
                {
                  name: <Code>Targets</Code>,
                  desc: "Id телепортов, к которым телепортирует телепорт",
                  values: (
                    <>
                      <Val code="add id" />
                      <Val code="remove id" />
                    </>
                  ),
                },
                {
                  name: <Code>Cooldown</Code>,
                  desc: "Задержка между телепортациями",
                  values: <Val code="1" />,
                },
              ]}
            />

            <Divider />

            <h3
              data-toc="Свойства Workstation"
              className="text-lg font-black uppercase tracking-widest text-white border-l-2 border-scp-orange pl-3"
            >
              Свойства Workstation
            </h3>
            <PropertyTable
              cols={[2, 5, 5]}
              rows={[
                {
                  name: <Code>IsInteractable</Code>,
                  desc: "Можно ли взаимодействовать с этим столом",
                  values: (
                    <>
                      <Val code="False" text="нет" />
                      <Val code="True" text="да" />
                    </>
                  ),
                },
              ]}
            />

            <Divider />

            <h3
              data-toc="Свойства TextToy"
              className="text-lg font-black uppercase tracking-widest text-white border-l-2 border-scp-orange pl-3"
            >
              Свойства TextToy
            </h3>
            <PropertyTable
              cols={[2, 5, 5]}
              rows={[
                {
                  name: <Code>Text</Code>,
                  desc: "Текст, который будет на вашем объекте",
                  values: <Val code={"<color=red><size=67>Hello world!"} />,
                },
              ]}
            />

            <Divider />

            <h3
              data-toc="Свойства Scp079Camera"
              className="text-lg font-black uppercase tracking-widest text-white border-l-2 border-scp-orange pl-3"
            >
              Свойства Scp079Camera
            </h3>
            <PropertyTable
              cols={[2, 5, 5]}
              rows={[
                {
                  name: <Code>CameraType</Code>,
                  desc: "Внешний вид камеры",
                  values: (
                    <>
                      <Val code="Lcz" text="камера из Легкой Зоны" />
                      <Val code="Hcz" text="камера из Тяжелой Зоны" />
                      <Val code="Ez" text="камера из Офисной Зоны" />
                      <Val code="EzArm" text="усиленная камера из Офисной Зоны" />
                      <Val code="Sz" text="камера с Поверхности" />
                    </>
                  ),
                },
                {
                  name: <Code>Label</Code>,
                  desc: "Название камеры в интерфейсе SCP-079",
                  values: <Val code="TestRoom" />,
                },
              ]}
            />

            <Divider />

            <h3
              data-toc="Свойства ShootingTarget"
              className="text-lg font-black uppercase tracking-widest text-white border-l-2 border-scp-orange pl-3"
            >
              Свойства ShootingTarget
            </h3>
            <PropertyTable
              cols={[2, 5, 5]}
              rows={[
                {
                  name: <Code>TargetType</Code>,
                  desc: "Тип мишени",
                  values: (
                    <>
                      <Val code="Sport" />
                      <Val code="ClassD" />
                      <Val code="Binary" />
                    </>
                  ),
                },
              ]}
            />

            <Divider />

            <h3
              data-toc="Свойства PlayerSpawnpoint"
              className="text-lg font-black uppercase tracking-widest text-white border-l-2 border-scp-orange pl-3"
            >
              Свойства PlayerSpawnpoint
            </h3>
            <PropertyTable
              cols={[2, 4, 6]}
              rows={[
                {
                  name: <Code>Roles</Code>,
                  desc: "Роли, которые будут возрождаться на этой точке. Если точек несколько, то будет выбрана случайная",
                  values: (
                    <>
                      <Val code="add `id роли`" />
                      <Val code="remove `id роли`" />
                      <div className="text-zinc-500">
                        ID ролей нужно добавлять и удалять по одному, их можно найти ниже
                      </div>
                    </>
                  ),
                },
              ]}
            />

            <Divider />

            <h3
              data-toc="Другие объекты"
              className="text-lg font-black uppercase tracking-widest text-white border-l-2 border-scp-orange pl-3"
            >
              Другие объекты
            </h3>
            <div className="space-y-2 mt-4">
              <div>
                <Code>Capybara</Code> — у нее нет свойств
              </div>
              <div>
                <Code>Interactable</Code>, <Code>Waypoint</Code> — не нужны вне схематика
              </div>
            </div>
          </Panel>
        </div>
      </InfoSectionCenter>

      {/* ============================== Прочее ============================== */}
      <InfoSectionCenter title="Прочее" id="other">
        <div className="space-y-5 text-[15px] sm:text-base">
          {/* ---------- Кастомное освещение ---------- */}
          <Panel>
            <PanelTitle toc="Кастомное освещение">Кастомное освещение</PanelTitle>
            <div className="grid lg:grid-cols-2 gap-6 mt-5 items-start">
              <img
                src={withBasePath("/images/other1.png")}
                alt="Кастомное освещение комнаты через команду ccolor"
                loading="lazy"
                className="rounded-xl hover:scale-105 transition-transform max-w-full h-auto w-full border border-zinc-800"
              />
              <div className="space-y-3">
                <p>
                  Помимо создания различных объектов, вы можете задавать цвет освещения в отдельных комнатах. Выключить
                  свет этой командой в определенной комнате не получится, потому что если поставить все значения на 0,
                  то свет становится примерно как при ночном видении у SCP.
                </p>
                <CmdBlock>ccolor r g b</CmdBlock>
                <p>
                  r — количество <span className="text-red-500">красного</span> в цвете.
                </p>
                <p>
                  g — количество <span className="text-green-500">зеленого</span> в цвете.
                </p>
                <p>
                  b — количество <span className="text-blue-500">синего</span> в цвете.
                </p>
              </div>
            </div>
          </Panel>

          {/* ---------- Текст интеркома ---------- */}
          <Panel>
            <PanelTitle toc="Текст интеркома">Текст интеркома</PanelTitle>
            <div className="grid lg:grid-cols-2 gap-6 mt-5 items-start">
              <img
                src={withBasePath("/images/other2.png")}
                alt="Кастомный текст на мониторе интеркома"
                loading="lazy"
                className="rounded-xl hover:scale-105 transition-transform max-w-full h-auto w-full border border-zinc-800"
              />
              <div className="space-y-3">
                <p>Меняет текст на мониторе интеркома.</p>
                <CmdBlock>intercomtext [текст]</CmdBlock>
                <p>
                  Можно изменить размер текста с помощью <Code>{"<size=>"}</Code>, а также цвет с помощью{" "}
                  <Code>{"<color=>"}</Code>.
                </p>
                <p>
                  Чтобы вернуть стандартный текст, нужно просто прописать <Code>intercomtext</Code>.
                </p>
              </div>
            </div>
          </Panel>

          {/* ---------- Различные команды ---------- */}
          <Panel>
            <PanelTitle toc="Различные команды">Различные команды</PanelTitle>
            <div className="mt-4">
              <CommandTable
                colsFirst={5}
                rows={[
                  { cmd: "scale id размер", text: "Меняет размер игрока по id во всех направлениях" },
                  {
                    cmd: "size id x y z",
                    text: "Меняет размер игрока отдельно для каждой координаты. Если поставить одну из координат меньше нуля, то у игрока инвертируется управление в одной из плоскостей",
                  },
                  { cmd: "breakdoors id", text: "Позволяет игроку выбивать двери, вместо их открытия" },
                  {
                    cmd: "prygate id",
                    text: "Позволяет игроку открывать закрытые гермоворота, так как это делает SCP-096",
                  },
                  {
                    cmd: "drop `id игрока` `id предмета` количество",
                    text: "Создает указанное количество, указанных предметов под игроком",
                  },
                  {
                    cmd: "dropsize `id игрока` `id предмета` x y z",
                    text: "Создает указанный предмет с указанным размером, под игроком",
                  },
                  {
                    cmd: "randomtp id",
                    text: "Телепортирует игрока в случайную комнату (на данный момент команда сломана)",
                  },
                ]}
              />
            </div>
          </Panel>

          {/* ---------- Использование команд на множество игроков ---------- */}
          <Panel>
            <PanelTitle toc="Использование команд на множество игроков">
              Использование команд на множество игроков
            </PanelTitle>
            <p className="mt-4">
              Иногда нужно выделить целую группу людей, например всех сержантов МОГ, чтобы выдать им cinfo. Вместо того
              чтобы выдавать им cinfo по одному, можно выдать сразу всем с помощью id класса:
            </p>

            <div className="mt-4 border border-red-900/60 bg-red-950/20 rounded-lg p-3 flex items-center gap-4">
              <div className="flex flex-col gap-1.5 items-start min-w-0">
                <span className="text-xs font-black uppercase tracking-widest text-red-500">Неправильно</span>
                <Code>cinfo 23 Сержант МОГ | 3 УД</Code>
                <Code>cinfo 33 Сержант МОГ | 3 УД</Code>
                <Code>cinfo 13 Сержант МОГ | 3 УД</Code>
              </div>
              <X className="w-14 h-14 sm:w-20 sm:h-20 text-red-500 shrink-0" aria-hidden="true" />
            </div>
            <div className="mt-2 border border-green-900/60 bg-green-950/20 rounded-lg p-3 flex items-center gap-4">
              <div className="flex flex-col gap-1.5 items-start min-w-0">
                <span className="text-xs font-black uppercase tracking-widest text-green-500">Правильно</span>
                <Code>cinfo ntfsergeant Сержант МОГ | 3 УД</Code>
              </div>
              <Check className="w-12 h-12 sm:w-14 sm:h-14 text-green-400 shrink-0" aria-hidden="true" />
            </div>

            <div className="space-y-3 mt-4">
              <p>
                Также можно выполнять команду для отдельных нескольких ID, достаточно прописать их через точку:{" "}
                <Code>setname 13.23.33 ???</Code>
              </p>
              <p>
                Это также работает и с id целых классов: <Code>setname ntfsergeant.classd.facilityguard ???</Code>
              </p>
              <p className="text-sm text-zinc-500">
                ID роли можно найти в самой игре: нажмите по человеку с необходимой ролью{" "}
                <Code>{"-> Request Data -> Request"}</Code>. В строке Class вы найдете класс, здоровье, щит SCP и щит
                от эффектов.
              </p>
            </div>

            <div className="mt-5">
              <Group title="Id классов">
                <div className="space-y-5">
                  <div>
                    <p className="text-xs font-black uppercase tracking-widest text-scp-orange mb-2">Классы</p>
                    <div className="grid sm:grid-cols-2 gap-x-6 gap-y-1.5">
                      {CLASS_ROLES.map(([id, name]) => (
                        <div key={id} className="flex items-baseline gap-2 text-sm">
                          <Code>{id}</Code>
                          <span className="text-zinc-400">— {name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-xs font-black uppercase tracking-widest text-scp-orange mb-2">Сокращения</p>
                    <div className="grid sm:grid-cols-2 gap-x-6 gap-y-1.5">
                      {CLASS_ABBREVS.map(([id, name]) => (
                        <div key={id} className="flex items-baseline gap-2 text-sm">
                          <Code>{id}</Code>
                          <span className="text-zinc-400">— {name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-xs font-black uppercase tracking-widest text-scp-orange mb-2">Команды</p>
                    <div className="grid sm:grid-cols-2 gap-x-6 gap-y-1.5">
                      {CLASS_COMMANDS.map(([id, name]) => (
                        <div key={id} className="flex items-baseline gap-2 text-sm">
                          <Code>{id}</Code>
                          <span className="text-zinc-400">— {name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </Group>
            </div>
          </Panel>
        </div>
      </InfoSectionCenter>
    </div>
  );
}
