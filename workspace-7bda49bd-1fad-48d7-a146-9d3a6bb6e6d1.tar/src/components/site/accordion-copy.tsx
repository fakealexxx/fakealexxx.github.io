"use client";

/**
 * Аккордеон с копированием кодов — сердце сайта.
 * Улучшения относительно оригинала:
 *  - поиск/фильтр по всем записям внутри секции;
 *  - кнопки «раскрыть всё» / «свернуть всё»;
 *  - счётчики записей в заголовках групп;
 *  - тост-уведомления при копировании.
 */
import React, { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown, Copy, Check, Search, ChevronsDownUp, ChevronsUpDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import type { DataItem } from "@/data/site-config";

const INPUT_RE = /\{\{input(?::([^}]+))?\}\}/g;

interface ItemCardProps {
  item: DataItem;
  cardId: string;
  copiedKey: string | null;
  setCopiedKey: (key: string | null) => void;
}

/** Карточка одной записи с полями ввода и копированием */
function ItemCard({ item, cardId, copiedKey, setCopiedKey }: ItemCardProps) {
  const inputMatches = [...item.code.matchAll(INPUT_RE)];
  const inputCount = inputMatches.length;
  const placeholders = inputMatches.map((m) => m[1] || "");
  const [inputValues, setInputValues] = useState<string[]>(new Array(inputCount).fill(""));
  const hasInputs = inputCount > 0;

  const buildFinalCode = (): string => {
    if (!hasInputs) return item.code;
    let index = 0;
    return item.code.replace(INPUT_RE, () => inputValues[index++] || "");
  };
  const finalCode = buildFinalCode();

  const updateInputValue = (index: number, value: string) => {
    const next = [...inputValues];
    next[index] = value;
    setInputValues(next);
  };

  const renderCodeWithInputs = () => {
    if (!hasInputs) return <>{item.code}</>;
    const parts = item.code.split(/(\{\{input(?::[^}]+)?\}\})/);
    let inputIndex = 0;
    return parts.map((part, idx) => {
      if (part.match(/\{\{input(?::[^}]+)?\}\}/)) {
        const current = inputIndex;
        const placeholder = placeholders[current] || `#${current + 1}`;
        inputIndex++;
        return (
          <input
            key={`input-${idx}`}
            type="text"
            inputMode="numeric"
            value={inputValues[current]}
            onChange={(e) => updateInputValue(current, e.target.value)}
            placeholder={placeholder}
            onClick={(e) => e.stopPropagation()}
            aria-label={placeholder}
            className="bg-zinc-950 border border-zinc-800 focus:border-scp-orange/60 rounded px-2 py-1 mx-1 text-xs font-mono text-zinc-200 min-w-[75px] max-w-[150px] focus:outline-none transition-all placeholder:text-zinc-600 inline-block align-middle my-0.5"
            style={{ width: `${Math.max(75, placeholder.length * 8)}px` }}
          />
        );
      }
      return <span key={idx}>{part}</span>;
    });
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(finalCode);
    } catch {
      // Fallback для окружений без clipboard API
      const ta = document.createElement("textarea");
      ta.value = finalCode;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    setCopiedKey(cardId);
    toast.success("Скопировано", { description: item.name });
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="bg-zinc-900/50 p-4 rounded-xl border border-zinc-800/80 hover:border-scp-orange/40 transition-all w-full overflow-hidden flex flex-col gap-3">
      <div className="flex items-start justify-between gap-3">
        <span className="text-sm sm:text-base font-bold text-zinc-300 uppercase tracking-tight break-words flex-1">
          {item.name}
        </span>
        <button
          onClick={handleCopy}
          aria-label={`Копировать: ${item.name}`}
          className={cn(
            "p-2 rounded-lg transition-colors shrink-0 border flex items-center justify-center",
            copiedKey === cardId
              ? "bg-green-950/30 border-green-800 text-green-400"
              : "bg-zinc-800/30 border-zinc-800 text-zinc-500 hover:bg-zinc-800 hover:text-scp-orange"
          )}
        >
          {copiedKey === cardId ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
        </button>
      </div>

      <div className="rich-text-preview text-xs sm:text-sm opacity-90 whitespace-pre-wrap break-words text-[#94949E] bg-black/30 p-3 rounded-lg border border-zinc-950 leading-relaxed">
        {renderCodeWithInputs()}
      </div>

      {hasInputs && inputValues.some((v) => v.length > 0) && (
        <div className="pt-2 border-t border-zinc-800/80">
          <div className="text-[10px] text-zinc-500 uppercase tracking-wider mb-1 font-bold">
            Результат сборки:
          </div>
          <div className="text-xs text-scp-orange font-mono bg-zinc-950/50 p-2 rounded border border-zinc-900/50 break-all select-all">
            {finalCode}
          </div>
        </div>
      )}
    </div>
  );
}

interface AccordionCopyProps {
  items: DataItem[];
  /** Подсказка-плейсхолдер для поиска */
  searchPlaceholder?: string;
}

export function AccordionCopy({ items, searchPlaceholder }: AccordionCopyProps) {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [openGroups, setOpenGroups] = useState<string[]>([]);
  const [openSubgroups, setOpenSubgroups] = useState<string[]>([]);
  const [query, setQuery] = useState("");

  const toggle = (
    list: string[],
    setList: React.Dispatch<React.SetStateAction<string[]>>,
    id: string
  ) => setList((prev) => (prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]));

  const q = query.trim().toLowerCase();

  const groupedItems = useMemo(() => {
    const filtered = q
      ? items.filter(
          (item) =>
            item.name.toLowerCase().includes(q) ||
            item.group.toLowerCase().includes(q) ||
            item.subgroup.toLowerCase().includes(q) ||
            item.code.toLowerCase().includes(q)
        )
      : items;

    return filtered.reduce(
      (acc, item) => {
        if (!acc[item.group]) acc[item.group] = { withSub: {}, withoutSub: [] };
        if (item.subgroup && item.subgroup.trim() !== "") {
          if (!acc[item.group].withSub[item.subgroup]) acc[item.group].withSub[item.subgroup] = [];
          acc[item.group].withSub[item.subgroup].push(item);
        } else {
          acc[item.group].withoutSub.push(item);
        }
        return acc;
      },
      {} as Record<string, { withSub: Record<string, DataItem[]>; withoutSub: DataItem[] }>
    );
  }, [items, q]);

  const totalGroups = Object.keys(groupedItems).length;
  const totalShown = Object.values(groupedItems).reduce(
    (sum, g) => sum + g.withoutSub.length + Object.values(g.withSub).flat().length,
    0
  );

  const expandAll = () => {
    setOpenGroups(Object.keys(groupedItems));
    const subs: string[] = [];
    Object.entries(groupedItems).forEach(([group, data]) =>
      Object.keys(data.withSub).forEach((sub) => subs.push(`${group}::${sub}`))
    );
    setOpenSubgroups(subs);
  };
  const collapseAll = () => {
    setOpenGroups([]);
    setOpenSubgroups([]);
  };

  return (
    <div className="space-y-4">
      {/* Панель поиска и управления */}
      <div className="flex flex-col sm:flex-row gap-3 sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={searchPlaceholder ?? "Поиск по названию или тексту..."}
            aria-label="Поиск по записям"
            className="w-full bg-zinc-900/60 border border-zinc-800 rounded-lg pl-9 pr-9 py-2.5 text-sm text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:border-scp-orange/50 transition-colors"
          />
          {query && (
            <button
              onClick={() => setQuery("")}
              aria-label="Очистить поиск"
              className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-600 hover:text-zinc-300"
            >
              <Search className="w-4 h-4" />
            </button>
          )}
        </div>
        <div className="flex gap-2">
          <button
            onClick={expandAll}
            className="flex items-center gap-2 px-3 py-2.5 rounded-lg bg-zinc-900/60 border border-zinc-800 text-xs font-bold uppercase tracking-wider text-zinc-500 hover:text-zinc-200 hover:border-scp-orange/40 transition-all"
          >
            <ChevronsUpDown className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Раскрыть всё</span>
          </button>
          <button
            onClick={collapseAll}
            className="flex items-center gap-2 px-3 py-2.5 rounded-lg bg-zinc-900/60 border border-zinc-800 text-xs font-bold uppercase tracking-wider text-zinc-500 hover:text-zinc-200 hover:border-scp-orange/40 transition-all"
          >
            <ChevronsDownUp className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Свернуть всё</span>
          </button>
        </div>
      </div>

      {q && (
        <div className="text-xs font-bold uppercase tracking-widest text-scp-orange">
          Найдено записей: {totalShown}
        </div>
      )}

      {totalGroups === 0 && (
        <div className="text-center py-12 text-zinc-500 uppercase tracking-widest text-sm font-bold">
          Ничего не найдено
        </div>
      )}

      {Object.entries(groupedItems).map(([group, data]) => {
        const groupCount =
          data.withoutSub.length + Object.values(data.withSub).reduce((s, arr) => s + arr.length, 0);
        return (
          <div key={group} className="scp-panel rounded-lg overflow-hidden border border-zinc-800">
            <button
              onClick={() => toggle(openGroups, setOpenGroups, group)}
              aria-expanded={openGroups.includes(group)}
              className="w-full flex items-center justify-between p-4 bg-zinc-800/50 hover:bg-zinc-800 transition-colors"
            >
              <h3 className="text-sm font-black uppercase tracking-[0.2em] text-scp-orange flex items-center gap-3">
                <div className="w-1.5 h-1.5 bg-scp-orange" />
                {group}
                <span className="text-[11px] opacity-50 font-mono">[{groupCount}]</span>
              </h3>
              <ChevronDown
                className={cn("w-5 h-5 transition-transform", openGroups.includes(group) && "rotate-180")}
              />
            </button>

            <AnimatePresence initial={false}>
              {openGroups.includes(group) && (
                <motion.div
                  initial={{ height: 0 }}
                  animate={{ height: "auto" }}
                  exit={{ height: 0 }}
                  transition={{ duration: 0.25 }}
                  className="overflow-hidden bg-black/20"
                >
                  <div className="p-3 space-y-4">
                    {Object.entries(data.withSub).map(([subgroup, subItems]) => {
                      const subId = `${group}::${subgroup}`;
                      return (
                        <div key={subgroup} className="rounded border border-zinc-800/50 overflow-hidden">
                          <button
                            onClick={() => toggle(openSubgroups, setOpenSubgroups, subId)}
                            aria-expanded={openSubgroups.includes(subId)}
                            className="w-full flex items-center justify-between p-2 px-4 bg-zinc-900/40 hover:bg-zinc-900/80 text-[13px] font-bold text-zinc-400 uppercase tracking-widest transition-colors"
                          >
                            <span className="flex items-center gap-2">
                              {subgroup}
                              <span className="text-[11px] opacity-40 font-mono">[{subItems.length}]</span>
                            </span>
                            <ChevronDown
                              className={cn(
                                "w-3 h-3 transition-transform",
                                openSubgroups.includes(subId) && "rotate-180"
                              )}
                            />
                          </button>
                          <AnimatePresence initial={false}>
                            {openSubgroups.includes(subId) && (
                              <motion.div
                                initial={{ height: 0 }}
                                animate={{ height: "auto" }}
                                exit={{ height: 0 }}
                                transition={{ duration: 0.2 }}
                                className="overflow-hidden"
                              >
                                <div className="p-3 grid gap-3">
                                  {subItems.map((item, idx) => (
                                    <ItemCard
                                      key={idx}
                                      item={item}
                                      cardId={`${subId}-${idx}`}
                                      copiedKey={copiedKey}
                                      setCopiedKey={setCopiedKey}
                                    />
                                  ))}
                                </div>
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                      );
                    })}
                    {data.withoutSub.length > 0 && (
                      <div className="grid gap-3 pt-1">
                        {data.withoutSub.map((item, idx) => (
                          <ItemCard
                            key={idx}
                            item={item}
                            cardId={`${group}-no-sub-${idx}`}
                            copiedKey={copiedKey}
                            setCopiedKey={setCopiedKey}
                          />
                        ))}
                      </div>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}
    </div>
  );
}
