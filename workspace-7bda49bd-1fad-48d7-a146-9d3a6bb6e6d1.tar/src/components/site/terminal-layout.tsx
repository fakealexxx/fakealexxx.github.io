"use client";

/**
 * Основной каркас сайта: сайдбар с навигацией и оглавлением,
 * мобильное меню, CRT-эффекты, футер и индикатор соединения.
 */
import React, { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Home, Users, Info, Megaphone, IdCard, History, Menu, X, Search } from "lucide-react";
import { cn } from "@/lib/utils";
import { useTOCState, useTOCRefresh } from "./toc-context";
import { SITE_CONFIG } from "@/data/site-config";
import { withBasePath } from "@/lib/base-path";
import { type Route } from "@/hooks/use-hash-route";

const NAV_ITEMS: { to: Route; label: string; icon: React.ElementType }[] = [
  { to: "/", label: "Главная", icon: Home },
  { to: "/cinfo", label: "Custom-Info", icon: Users },
  { to: "/cassie", label: "C.A.S.S.I.E", icon: Megaphone },
  { to: "/keycards", label: "Ключ-карты", icon: IdCard },
  { to: "/information", label: "Информация", icon: Info },
  { to: "/history", label: "История", icon: History },
];

export function NavLinks({
  route,
  onNavigate,
  className,
}: {
  route: Route;
  onNavigate?: (to: Route) => void;
  className?: string;
}) {
  return (
    <div className={cn("flex flex-col", className)}>
      {NAV_ITEMS.map((item) => {
        const isActive = route === item.to;
        const Icon = item.icon;
        return (
          <a
            key={item.to}
            href={`#${item.to}`}
            onClick={onNavigate ? () => onNavigate(item.to) : undefined}
            aria-current={isActive ? "page" : undefined}
            className={cn(
              "group relative flex items-center gap-3 px-6 py-4 transition-all border-r-4 outline-none",
              isActive
                ? "bg-zinc-800/40 border-scp-orange text-scp-orange"
                : "border-transparent text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/40 focus-visible:text-scp-orange"
            )}
          >
            <Icon
              className={cn(
                "w-5 h-5 transition-transform group-hover:scale-110",
                isActive && "scp-glitch"
              )}
            />
            <span className="text-xs font-black uppercase tracking-widest">{item.label}</span>
            {isActive && (
              <motion.div
                layoutId="nav-glow"
                className="absolute inset-0 bg-scp-orange/5 blur-xl pointer-events-none"
              />
            )}
          </a>
        );
      })}
    </div>
  );
}

interface TOCEntry {
  id: string;
  text: string;
  level: number;
}

export function TerminalLayout({
  route,
  children,
  onOpenSearch,
}: {
  route: Route;
  children: React.ReactNode;
  onOpenSearch: () => void;
}) {
  const [toc, setToc] = useState<TOCEntry[]>([]);
  const [mobileOpen, setMobileOpen] = useState(false);
  const showTOC = useTOCState();
  const { refreshTrigger } = useTOCRefresh();
  const contentRef = useRef<HTMLDivElement>(null);
  const mainScrollRef = useRef<HTMLElement>(null);
  const [scrollProgress, setScrollProgress] = useState(0);

  // Закрываем мобильное меню при любом изменении hash (переход, кнопка назад)
  useEffect(() => {
    const close = () => setMobileOpen(false);
    window.addEventListener("hashchange", close);
    return () => window.removeEventListener("hashchange", close);
  }, []);

  // Сбор заголовков для оглавления
  useEffect(() => {
    const timer = setTimeout(() => {
      if (!showTOC || !contentRef.current) {
        setToc([]);
        return;
      }
      const headers = contentRef.current.querySelectorAll("h2[data-toc], h3[data-toc]");
      const items: TOCEntry[] = Array.from(headers).map((header, index) => {
        if (!header.id) header.id = `toc-header-${index}`;
        return {
          id: header.id,
          text: header.getAttribute("data-toc") || header.textContent || "",
          level: parseInt(header.tagName.substring(1)),
        };
      });
      setToc(items);
    }, 120);
    return () => clearTimeout(timer);
  }, [route, refreshTrigger, showTOC, children]);

  // Полоса прогресса чтения
  useEffect(() => {
    const main = mainScrollRef.current;
    if (!main) return;
    const onScroll = () => {
      const max = main.scrollHeight - main.clientHeight;
      setScrollProgress(max > 0 ? main.scrollTop / max : 0);
    };
    const raf = requestAnimationFrame(onScroll);
    main.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      cancelAnimationFrame(raf);
      main.removeEventListener("scroll", onScroll);
    };
  }, [route]);

  const scrollToHeader = (id: string) => {
    const el = document.getElementById(id);
    el?.scrollIntoView({ behavior: "smooth" });
  };

  const sidebarInner = (
    <>
      {/* Логотип */}
      <div className="p-8 flex items-center justify-between relative">
        <a href="#/" className="flex items-center gap-3 text-scp-orange group">
          <img
            src={withBasePath("/images/litery.png")}
            alt="Логотип LITERY Events"
            className="w-12 h-12 transition-transform group-hover:rotate-6"
          />
          <div className="flex flex-col">
            <span className="text-xl font-black leading-none tracking-tighter uppercase">
              {SITE_CONFIG.siteName}
            </span>
            <span className="text-[10px] opacity-50 font-bold uppercase tracking-widest">
              {SITE_CONFIG.siteAuthor}
            </span>
          </div>
        </a>
        <div className="absolute bottom-0 left-0 right-0 h-px bg-zinc-800 overflow-hidden">
          <motion.div
            animate={{ x: ["-150%", "300%"] }}
            transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
            className="absolute inset-y-0 left-0 bg-scp-orange/50 w-1/3"
          />
        </div>
      </div>

      {/* Навигация */}
      <nav aria-label="Основная навигация" className="flex-1 overflow-y-auto py-4 custom-scrollbar">
        <NavLinks route={route} onNavigate={() => setMobileOpen(false)} />

        {/* Кнопка поиска */}
        <div className="px-4 mt-6 border-t border-zinc-800 pt-5">
          <button
            onClick={() => {
              setMobileOpen(false);
              onOpenSearch();
            }}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg bg-zinc-900/60 border border-zinc-800 text-zinc-500 hover:text-zinc-300 hover:border-scp-orange/40 transition-all text-left"
          >
            <Search className="w-4 h-4" />
            <span className="text-xs font-bold uppercase tracking-widest flex-1">Поиск</span>
            <kbd className="hidden lg:inline-flex items-center gap-0.5 text-[9px] font-mono bg-zinc-800 border border-zinc-700 rounded px-1.5 py-0.5">
              CTRL K
            </kbd>
          </button>
        </div>

        {/* Оглавление */}
        {showTOC && toc.length > 0 && (
          <div className="mt-6 mb-4 px-6" aria-label="Оглавление страницы">
            <div className="text-xs font-black uppercase tracking-widest text-zinc-400 mb-3 flex items-center gap-2">
              <div className="w-0.5 h-4 bg-scp-orange" />
              Оглавление
            </div>
            <div className="space-y-1 pr-2 max-h-[32vh] overflow-y-auto custom-scrollbar">
              {toc.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    scrollToHeader(item.id);
                    setMobileOpen(false);
                  }}
                  className={cn(
                    "block w-full text-left text-[9px] font-bold uppercase tracking-wider transition-colors hover:text-scp-orange",
                    item.level === 2 ? "pl-0 text-zinc-300" : "pl-3 text-zinc-500"
                  )}
                >
                  {item.text}
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Индикатор соединения */}
      <div className="p-6 border-t border-zinc-800 bg-zinc-900/20">
        <div className="flex items-center gap-2 text-zinc-500">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-500 opacity-60" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500" />
          </span>
          <span className="text-[10px] uppercase font-bold tracking-tighter">Соединение стабильно</span>
        </div>
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-scp-bg text-zinc-200">
      {/* Фоновые CRT-эффекты */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden" aria-hidden="true">
        <div className="absolute inset-0 crt-grid" />
        <div className="scanline" />
      </div>

      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-[100] focus:bg-scp-orange focus:text-black focus:px-3 focus:py-2 focus:rounded"
      >
        Перейти к содержимому
      </a>

      <div className="flex h-screen relative z-10 overflow-hidden">
        {/* Затемнение на мобильных */}
        {mobileOpen && (
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
            onClick={() => setMobileOpen(false)}
            aria-hidden="true"
          />
        )}

        {/* Сайдбар */}
        <aside
          className={cn(
            "fixed inset-y-0 left-0 z-50 w-64 border-r border-zinc-800 bg-black flex flex-col shrink-0 transition-transform duration-300 ease-in-out",
            "lg:static lg:translate-x-0",
            mobileOpen ? "translate-x-0" : "-translate-x-full"
          )}
          aria-label="Боковая панель"
        >
          {sidebarInner}
          <button
            onClick={() => setMobileOpen(false)}
            className="lg:hidden absolute top-4 right-4 p-2 text-zinc-500 hover:text-zinc-200"
            aria-label="Закрыть меню"
          >
            <X className="w-5 h-5" />
          </button>
        </aside>

        {/* Основной контент */}
        <main
          ref={mainScrollRef}
          className="flex-1 overflow-y-auto bg-zinc-950/20 relative flex flex-col"
          id="main-content"
        >
          {/* Полоса прогресса чтения */}
          <div className="sticky top-0 z-30 h-0.5 bg-transparent" aria-hidden="true">
            <div
              className="h-full bg-scp-orange/80 transition-[width] duration-150"
              style={{ width: `${scrollProgress * 100}%` }}
            />
          </div>

          {/* Мобильная шапка */}
          <div className="lg:hidden w-full bg-black/80 border-b border-zinc-800 p-4 flex items-center justify-between sticky top-0 z-30 backdrop-blur-md">
            <a href="#/" className="flex items-center gap-3 text-scp-orange">
              <img src={withBasePath("/images/litery.png")} alt="Логотип" className="w-8 h-8" />
              <span className="text-sm font-black uppercase tracking-widest leading-none">
                {SITE_CONFIG.siteName}
              </span>
            </a>
            <div className="flex items-center gap-1">
              <button
                onClick={onOpenSearch}
                className="p-2 text-zinc-400 hover:text-scp-orange focus:outline-none transition-colors"
                aria-label="Открыть поиск"
              >
                <Search className="w-5 h-5" />
              </button>
              <button
                onClick={() => setMobileOpen(true)}
                className="p-2 text-zinc-400 hover:text-zinc-200 focus:outline-none transition-colors"
                aria-label="Открыть меню"
              >
                <Menu className="w-6 h-6" />
              </button>
            </div>
          </div>

          {/* Контент страницы */}
          <div className="p-4 sm:p-8 lg:p-12 flex-1 w-full">
            <div className="max-w-6xl mx-auto" ref={contentRef}>
              <AnimatePresence mode="wait">
                <motion.div
                  key={route}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.35, ease: "easeOut" }}
                >
                  {children}
                </motion.div>
              </AnimatePresence>
            </div>
          </div>

          {/* Футер */}
          <footer className="mt-auto p-6 border-t border-zinc-900 text-zinc-600 text-[10px] flex flex-col sm:flex-row justify-between gap-2 uppercase tracking-widest font-bold bg-black/10 pb-[max(1.5rem,env(safe-area-inset-bottom))]">
            <div>{SITE_CONFIG.footerText}</div>
            <div>{SITE_CONFIG.footerYear}</div>
          </footer>
        </main>
      </div>
    </div>
  );
}
