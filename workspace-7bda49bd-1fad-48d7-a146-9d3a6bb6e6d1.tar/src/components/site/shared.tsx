"use client";

/**
 * Общие UI-блоки контента: секции, сворачиваемые группы, код-чипы.
 */
import React, { useState } from "react";
import { ChevronDown, Layers } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";

/** Секция-панель с заголовком h2 (участвует в оглавлении) */
export function InfoSection({
  title,
  children,
  className,
  id,
}: {
  title: string;
  children: React.ReactNode;
  className?: string;
  id?: string;
}) {
  return (
    <section
      id={id}
      className={cn("scp-panel p-4 sm:p-8 rounded-2xl relative overflow-hidden group border-scp-border", className)}
    >
      <div className="absolute top-0 right-0 w-32 h-32 bg-scp-orange/5 blur-[60px] pointer-events-none group-hover:bg-scp-orange/10 transition-colors" />
      <div className="relative z-10 space-y-4">
        <h2
          data-toc={title}
          className="text-xl sm:text-2xl font-black uppercase tracking-widest text-white group-hover:scp-glitch transition-all"
        >
          {title}
        </h2>
        <div className="h-px w-24 bg-scp-orange/30 group-hover:w-full transition-all duration-700" />
        <div className="text-zinc-400 text-sm leading-relaxed font-medium space-y-4">{children}</div>
      </div>
    </section>
  );
}

/** Секция с центрированным заголовком */
export function InfoSectionCenter({
  title,
  children,
  id,
}: {
  title: string;
  children: React.ReactNode;
  id?: string;
}) {
  return (
    <section
      id={id}
      className="scp-panel p-4 sm:p-8 rounded-2xl relative overflow-hidden group border-scp-border"
    >
      <div className="absolute top-0 right-0 w-32 h-32 bg-scp-orange/5 blur-[60px] pointer-events-none group-hover:bg-scp-orange/10 transition-colors" />
      <div className="relative z-10 space-y-4">
        <h2
          data-toc={title}
          className="text-xl sm:text-2xl font-black uppercase tracking-widest text-white group-hover:scp-glitch flex justify-center text-center transition-all"
        >
          {title}
        </h2>
        <div className="text-zinc-400 text-sm leading-relaxed font-medium space-y-4">{children}</div>
      </div>
    </section>
  );
}

/** Моноширинный код-чип */
export function Code({ children }: { children: React.ReactNode }) {
  return (
    <code className="text-zinc-100 bg-zinc-800 border border-zinc-700/50 rounded px-1.5 py-0.5 text-[0.85em] font-mono break-all">
      {children}
    </code>
  );
}

/** Сворачиваемая группа (h3 — участвует в оглавлении) */
export function Group({
  title,
  children,
  header = true,
  defaultOpen = false,
}: {
  title: string;
  children: React.ReactNode;
  header?: boolean;
  defaultOpen?: boolean;
}) {
  const [isOpen, setIsOpen] = useState(defaultOpen);
  const TitleTag = header ? "h3" : "p";

  return (
    <div className="overflow-hidden rounded-lg bg-zinc-950 border border-zinc-900">
      <button
        onClick={() => setIsOpen(!isOpen)}
        aria-expanded={isOpen}
        className="w-full flex items-center justify-between p-4 cursor-pointer hover:bg-zinc-900 transition-colors"
      >
        <TitleTag
          data-toc={header ? title : undefined}
          className="text-xs font-black uppercase tracking-widest flex items-center gap-3 text-zinc-300"
        >
          <Layers className="w-4 h-4 text-scp-orange" />
          {title}
        </TitleTag>
        <div
          className={cn(
            "w-6 h-6 rounded bg-zinc-800 flex items-center justify-center transition-transform duration-300",
            isOpen && "rotate-180"
          )}
        >
          <ChevronDown className="w-5 h-5 text-zinc-300" />
        </div>
      </button>

      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.div
            initial={{ height: 0 }}
            animate={{ height: "auto" }}
            exit={{ height: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden"
          >
            <div className="p-4 pt-0 border-t border-zinc-900 text-zinc-300">{children}</div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/** Заголовок страницы (h1 + описание с оранжевой чертой) */
export function PageHeader({
  title,
  highlight,
  titleSuffix,
  description,
}: {
  title: string;
  highlight?: string;
  titleSuffix?: string;
  description: string;
}) {
  return (
    <div className="border-b border-zinc-800 pb-10">
      <h1 className="text-3xl sm:text-5xl font-black uppercase tracking-wide sm:tracking-[0.19em] text-white">
        {title}
        {highlight && <span className="text-scp-orange">{highlight}</span>}
        {titleSuffix}
      </h1>
      <p className="text-zinc-400 mt-4 font-bold uppercase tracking-widest text-xs sm:text-sm border-l-2 border-scp-orange pl-4">
        {description}
      </p>
    </div>
  );
}

/** Таблица-сетка в стиле оригинала (команда | описание) */
const COL_MAP: Record<number, [string, string]> = {
  2: ["sm:col-span-2", "sm:col-span-10"],
  3: ["sm:col-span-3", "sm:col-span-9"],
  4: ["sm:col-span-4", "sm:col-span-8"],
  5: ["sm:col-span-5", "sm:col-span-7"],
  6: ["sm:col-span-6", "sm:col-span-6"],
};

export function CommandTable({
  rows,
  colsFirst = 5,
}: {
  rows: { cmd: string; text: React.ReactNode }[];
  colsFirst?: number;
}) {
  const [firstCol, secondCol] = COL_MAP[colsFirst] ?? COL_MAP[5];
  return (
    <div className="border border-zinc-800 rounded-lg overflow-hidden">
      {rows.map((row, i) => (
        <div key={i} className={cn("grid grid-cols-12", i < rows.length - 1 && "border-b border-zinc-800")}>
          <div
            className={cn(
              "col-span-12 p-3 flex items-center sm:justify-center border-zinc-800",
              firstCol,
              i < rows.length - 1 && "sm:border-r border-b sm:border-b-0"
            )}
          >
            <Code>{row.cmd}</Code>
          </div>
          <div className={cn("col-span-12 p-3 flex items-center", secondCol)}>{row.text}</div>
        </div>
      ))}
    </div>
  );
}
