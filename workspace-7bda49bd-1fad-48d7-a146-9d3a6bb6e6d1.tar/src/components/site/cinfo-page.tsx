"use client";

/**
 * Страница Custom-Info: базы Cinfo по авторам с копированием.
 */
import React from "react";
import { PageHeader, InfoSection } from "./shared";
import { DatabaseSection } from "./database-section";
import { useTOC } from "./toc-context";

export function CinfoPage() {
  useTOC(false);

  return (
    <div className="space-y-10 pb-24">
      <PageHeader
        title="Custom-Info"
        description="Введите ID игрока/игроков в поле внутри текста и используйте кнопку справа от текста для копирования"
      />

      <InfoSection title="Aphin" id="section-aphin">
        <DatabaseSection databaseName="cinfo_aphin" />
      </InfoSection>

      <div className="border-b border-zinc-800" />

      <InfoSection title="Burst173" id="section-burst173">
        <DatabaseSection databaseName="cinfo_burst173" />
      </InfoSection>

      <div className="border-b border-zinc-800" />

      <InfoSection title="SoloSquad2008" id="section-solosquad2008">
        <DatabaseSection databaseName="cinfo_solosquad2008" />
      </InfoSection>
    </div>
  );
}
