"use client";

/**
 * Контекст оглавления (TOC) — как в оригинале: страницы включают
 * сбор заголовков h2/h3, сайдбар показывает ссылки с прокруткой.
 */
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

export interface TOCItem {
  id: string;
  text: string;
  level: number;
}

interface TOCContextType {
  enabled: boolean;
  setEnabled: (v: boolean) => void;
  refreshTrigger: number;
  refresh: () => void;
}

const TOCContext = createContext<TOCContextType | null>(null);

export function TOCProvider({ children }: { children: React.ReactNode }) {
  const [enabled, setEnabled] = useState(false);
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const refresh = useCallback(() => setRefreshTrigger((p) => p + 1), []);
  const value = useMemo(() => ({ enabled, setEnabled, refreshTrigger, refresh }), [enabled, refreshTrigger, refresh]);
  return <TOCContext.Provider value={value}>{children}</TOCContext.Provider>;
}

export function useTOC(enable = true) {
  const ctx = useContext(TOCContext);
  if (!ctx) throw new Error("useTOC должен использоваться внутри TOCProvider");
  useEffect(() => {
    ctx.setEnabled(enable);
    return () => ctx.setEnabled(false);
  }, [enable, ctx]);
}

export function useTOCState() {
  const ctx = useContext(TOCContext);
  return ctx?.enabled ?? false;
}

export function useTOCRefresh() {
  const ctx = useContext(TOCContext);
  return { refreshTrigger: ctx?.refreshTrigger ?? 0, refreshTOC: ctx?.refresh ?? (() => {}) };
}
