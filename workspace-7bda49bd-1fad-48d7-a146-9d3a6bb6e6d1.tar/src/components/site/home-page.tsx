"use client";

/**
 * Главная страница: терминал ивент-мастера, карточки разделов, статистика.
 */
import React, { useEffect, useRef, useState } from "react";
import { Users, Info, ArrowRight, Megaphone, IdCard, History } from "lucide-react";
import { motion, useInView } from "framer-motion";
import { SITE_CONFIG } from "@/data/site-config";
import { useDatabases } from "@/hooks/use-databases";
import type { Route } from "@/hooks/use-hash-route";

function Card({
  title,
  icon: Icon,
  to,
  delay = 0,
}: {
  title: string;
  icon: React.ElementType;
  to: Route;
  delay?: number;
}) {
  return (
    <motion.a
      href={`#${to}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.4 }}
      className="group relative"
    >
      <div className="absolute -inset-1 bg-scp-orange/10 rounded-lg blur opacity-25 group-hover:opacity-100 transition duration-500" />
      <div className="relative p-6 sm:p-8 bg-zinc-900/50 border border-zinc-800 rounded-lg hover:border-scp-orange/50 transition-all overflow-hidden h-full">
        <div className="flex justify-between items-start mb-6">
          <div className="p-4 bg-zinc-800 rounded-xl group-hover:bg-zinc-700 transition-colors text-scp-orange">
            <Icon className="w-8 h-8 sm:w-9 sm:h-9" />
          </div>
          <ArrowRight className="w-7 h-7 sm:w-8 sm:h-8 text-zinc-600 group-hover:text-scp-orange transition-all group-hover:translate-x-1" />
        </div>
        <h3 className="text-lg sm:text-xl font-black uppercase tracking-widest text-white group-hover:scp-glitch">
          {title}
        </h3>
        <div className="absolute bottom-0 left-0 h-1 w-0 bg-scp-orange group-hover:w-full transition-all duration-500" />
      </div>
    </motion.a>
  );
}

/** Карточка статистики с анимированным счётчиком */
function StatCard({ label, value, loading }: { label: string; value: string; loading?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true });
  // Анимируем только целые числа (даты типа "29.06.2026" показываем как есть)
  const isNumeric = /^\d+$/.test(value);
  const numeric = isNumeric ? parseInt(value, 10) : 0;
  const [display, setDisplay] = useState(isNumeric ? 0 : numeric);

  useEffect(() => {
    if (!inView || loading || isNaN(numeric)) return;
    const duration = 900;
    const start = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setDisplay(Math.round(numeric * eased));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, numeric, loading]);

  return (
    <div ref={ref} className="p-4 bg-zinc-900 border border-zinc-800 rounded-lg relative overflow-hidden group">
      <div className="absolute inset-0 bg-gradient-to-br from-scp-orange/0 group-hover:from-scp-orange/10 transition-all duration-500" />
      {loading ? (
        <>
          <div className="h-2.5 bg-zinc-700 rounded-full w-24 mb-2 animate-pulse" />
          <div className="h-5 bg-zinc-700 rounded-full w-12 animate-pulse" />
        </>
      ) : (
        <>
          <div className="text-[10px] text-zinc-500 font-black uppercase tracking-widest mb-1">{label}</div>
          <div className="text-xl font-mono text-scp-orange font-bold tracking-tighter">
            {isNumeric ? display : value}
          </div>
        </>
      )}
    </div>
  );
}

export function HomePage() {
  const { count, status } = useDatabases();
  const loading = status === "loading";

  const totalCinfo = count("cinfo_aphin", "cinfo_burst173", "cinfo_solosquad2008");
  const totalCassie = count("cassie_aphin", "cassie_dev1lmachine", "cassie_burst173");
  const totalKeycards = count("keycards_burst173", "keycards_solosquad2008");

  return (
    <div className="space-y-10 sm:space-y-12 pb-8">
      <div className="max-w-3xl">
        <h1 className="font-bold uppercase text-left mb-6 sm:mb-8 select-none">
          <span className="font-black leading-none text-4xl sm:text-7xl tracking-wider sm:tracking-[0.2em] text-white block">
            {SITE_CONFIG.heroTitleTop}
          </span>
          <span className="text-xl sm:text-5xl tracking-normal sm:tracking-[0.176em] text-scp-orange block mt-2 sm:mt-1">
            {SITE_CONFIG.heroTitleBottom}
          </span>
        </h1>
        <p className="text-sm sm:text-lg text-zinc-400 font-medium border-l-4 border-scp-orange pl-6 py-2 uppercase tracking-wide">
          {SITE_CONFIG.heroDescription}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card title="Custom-Info" icon={Users} to="/cinfo" delay={0} />
        <Card title="C.A.S.S.I.E" icon={Megaphone} to="/cassie" delay={0.07} />
        <Card title="Ключ-карты" icon={IdCard} to="/keycards" delay={0.14} />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 sm:gap-7 sm:-mt-3">
        <Card title="Информация" icon={Info} to="/information" delay={0.21} />
        <Card title="История" icon={History} to="/history" delay={0.28} />
      </div>

      {/* Статистика */}
      <div className="rounded-2xl p-4 relative group scp-panel mb-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-7">
          <StatCard label="Всего Custom-Info" value={String(totalCinfo)} loading={loading} />
          <StatCard label="Всего CASSIE" value={String(totalCassie)} loading={loading} />
          <StatCard label="Всего Ключ-карт" value={String(totalKeycards)} loading={loading} />
          <StatCard label="Последнее обновление" value={SITE_CONFIG.lastUpdate} />
        </div>
      </div>
    </div>
  );
}
