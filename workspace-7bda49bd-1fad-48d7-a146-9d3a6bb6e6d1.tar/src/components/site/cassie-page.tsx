"use client";

/**
 * Страница C.A.S.S.I.E: объявления для ивентов с копированием.
 */
import React from "react";
import { PageHeader, InfoSection } from "./shared";
import { DatabaseSection } from "./database-section";
import { useTOC } from "./toc-context";

export function CassiePage() {
  useTOC(false);

  return (
    <div className="space-y-10 pb-24">
      <PageHeader
        title="C.A.S.S.I.E"
        description="Используйте кнопку справа от текста для копирования"
      />

      <InfoSection title="Aphin & ComicManatee926" id="section-aphin">
        <DatabaseSection databaseName="cassie_aphin" />
      </InfoSection>

      <div className="border-b border-zinc-800" />

      <InfoSection title="Dev1lmachine" id="section-dev1lmachine">
        <DatabaseSection databaseName="cassie_dev1lmachine" />
      </InfoSection>

      <div className="border-b border-zinc-800" />

      <InfoSection title="Burst173" id="section-burst173">
        <DatabaseSection databaseName="cassie_burst173" />
      </InfoSection>
    </div>
  );
}
