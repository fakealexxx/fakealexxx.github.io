"use client";

/**
 * Страница «История изменений» — журнал изменений по сезонам.
 * Копия контента оригинального сайта (включая опечатки оригинала).
 */
import React from "react";
import { PageHeader, InfoSection, Group } from "./shared";
import { useTOC } from "./toc-context";
import { History, Sparkles } from "lucide-react";

/** Список изменений (диск с оранжевыми маркерами) */
function ChangeList({ children }: { children: React.ReactNode }) {
  return (
    <ul className="list-disc list-outside pl-5 space-y-2 text-zinc-300 text-sm sm:text-base leading-relaxed marker:text-scp-orange">
      {children}
    </ul>
  );
}

/** Важное примечание-вставка перед списком изменений */
function Note({ children }: { children: React.ReactNode }) {
  return (
    <p className="italic text-zinc-400 text-sm leading-relaxed border-l-2 border-scp-orange/50 bg-zinc-900/40 rounded-r-lg px-4 py-3">
      {children}
    </p>
  );
}

/** Сезон журнала — обёртка над InfoSection с рамкой-разделителем */
function SeasonSection({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="border-b border-zinc-800 pb-12">
      <InfoSection title={title}>{children}</InfoSection>
    </div>
  );
}

export function HistoryPage() {
  useTOC(true);

  return (
    <div className="space-y-12 pb-24">
      <PageHeader
        title="История "
        highlight="изменений"
        description="Журнал изменений разбит на сезоны для удобства"
      />

      {/* ── Вводные секции ─────────────────────────────────────────── */}
      <div className="border-b border-zinc-800 pb-12 space-y-10">
        <InfoSection title="Немного предыстории">
          <p className="text-zinc-300 text-sm leading-relaxed font-medium">
            Этот сайт был создан 7 июня 2025 года. Однако первая публикация состоялась немного позже.{" "}
            <br />
            Она включала в себя лишь C.A.S.S.I.E от бывшего ГИМ(Frezee, ныне глава отдела) и скромный
            список кастом инфо от бывшего главы отдела (ComicManatee926).
          </p>
        </InfoSection>

        <InfoSection title="Последние изменения - 29.06.2026">
          <div className="flex items-center gap-2 text-[10px] font-mono uppercase tracking-widest text-scp-orange/80">
            <Sparkles className="w-3.5 h-3.5" />
            Актуальное состояние сайта
          </div>
          <ChangeList>
            <li>Добавлены Cinfo и ключ-карты от Burst173 и solosquad2008.</li>
            <li>Удалены Cinfo от Dev1lMachine и смешанные ключ-карты.</li>
            <li>Удалены старые Cinfo и ключ-карты от solosquad2008.</li>
            <li>
              Частично улучшена совместимость с мобильными устройствами и мониторами, но их
              использование крайне не рекомендуется из-за проблем на половине страниц.
            </li>
            <li>
              <span className="italic text-scp-orange">Кстати сайту уже больше года...</span>
            </li>
          </ChangeList>
        </InfoSection>
      </div>

      {/* ── Лето 2025 ──────────────────────────────────────────────── */}
      <SeasonSection title="Лето 2025">
        <div className="space-y-4">
          <Group title="8 Июня">
            <div className="space-y-2">
              <ChangeList>
                <li>Добавлена страница &quot;Список ивентов&quot;.</li>
                <li>Добавлена страница &quot;Полезные команды и прочее&quot;.</li>
                <li>Некоторые C.A.S.S.I.E заменены на мои.</li>
              </ChangeList>
            </div>
          </Group>
          <Group title="9 - 13 Июня">
            <div className="space-y-2">
              <ChangeList>
                <li>Добавлена страница &quot;Ключ-карты&quot;.</li>
                <li>Сильно дополнена страница &quot;Разное&quot;.</li>
                <li>Возвращен ивент &quot;Переговорщики&quot;.</li>
              </ChangeList>
            </div>
          </Group>
          <Group title="21 - 23 Июня">
            <div className="space-y-2">
              <ChangeList>
                <li>К этому моменту все C.A.S.S.I.E были заменены на мои.</li>
                <li>Добавлены мини-ивенты &quot;Важный чин&quot; и &quot;Хищные грёзы&quot;.</li>
                <li>Добавлен мини-ивент &quot;SCP-966&quot;.</li>
              </ChangeList>
            </div>
          </Group>
          <Group title="13 - 16 Июля">
            <div className="space-y-3">
              <Note>Первое, отписанное мною изменение в канал новостей ивент-мастеров.</Note>
              <ChangeList>
                <li>Возвращен мини-ивент &quot;Неисправность&quot;.</li>
                <li>
                  Добавлены условия по количеству игроков для проведения мини-ивентов &quot;Хищные
                  Грёзы&quot;, &quot;SCP-966&quot;, &quot;Лазутчики&quot;.
                </li>
                <li>Для мини-ивента &quot;Бомба&quot; добавлено касси на прибытие саперов.</li>
                <li>Изменено оформление во вкладке &quot;Cinfo&quot;.</li>
                <li>
                  Некоторые незначительные изменения во вкладках &quot;C.A.S.S.I.E&quot; и
                  &quot;Разное&quot;.
                </li>
                <li>
                  В мини-ивент &quot;Неисправность&quot; было добавлено примечание:{" "}
                  <span className="italic text-zinc-400">
                    &quot;Ваши касси не должны использовать мета-информацию, то есть запрещено любое
                    упоминание людей по никам (исключение: у человека нет рп имени), а также
                    упоминание людей из наблюдателей и надзирателей.&quot;
                  </span>
                </li>
              </ChangeList>
            </div>
          </Group>
        </div>
      </SeasonSection>

      {/* ── Осень 2025 ─────────────────────────────────────────────── */}
      <SeasonSection title="Осень 2025">
        <div className="space-y-4">
          <Group title="2 Сентября">
            <div className="space-y-3">
              <Note>
                21 августа, Ивент-мастер mr. wdy XIII [926] предложил мне помощь по развитию сайта,
                потому что на тот момент ничего нового на сайте не было уже больше месяца. Больша́я
                часть изменений с этого момента производилась именно им.
              </Note>
              <ChangeList>
                <li>
                  Был произведен редизайн всего сайта, изменились цвета фона, заголовков, текста,
                  некоторые C.A.S.S.I.E перенесены в соответствующие сворачиваемые группы.
                </li>
                <li>
                  Были добавлены C.A.S.S.I.E и Cinfo авторства Dev1lMachine, но на тот момент они
                  были не стилизованы, так как делалось все чтобы загрузить информацию на сайт как
                  можно быстрее.
                </li>
                <li>
                  Был создан раздел <span className="text-scp-orange">&quot;C.A.S.S.I.E | Раунд&quot;</span>.
                </li>
                <li>
                  Вкладка &quot;Полезная информация и прочее&quot; была переименована просто в
                  &quot;Прочее&quot;, а вкладка &quot;C.A.S.S.I.E&quot; в &quot;C.A.S.S.I.E | Ивент&quot;
                </li>
                <li>
                  Раздел &quot;Прочее&quot; претерпел некоторые изменения: Гайд на создание ключ карт
                  был перенесен на страницу &quot;Ключ-карты&quot;, ID классов перенесен вверх,
                  добавлены некоторые уточнения в команды.
                </li>
                <li>
                  В разделах &quot;Прочее&quot;, &quot;C.A.S.S.I.E&quot; и &quot;Cinfo&quot; появились
                  оглавления для удобства.
                </li>
                <li>
                  Так же восстановлены некоторые утерянные картинки на основной странице и в разделе
                  &quot;Ключ-карты&quot;.
                </li>
              </ChangeList>
            </div>
          </Group>
          <Group title="7 Сентября">
            <div className="space-y-2">
              <ChangeList>
                <li>
                  Постепенно происходил дальнейший редизайн разделов &quot;C.A.S.S.I.E&quot; и
                  &quot;Cinfo&quot;.
                </li>
                <li>Были добавлены цветные Cinfo моего авторства.</li>
                <li>Временно добавлены &quot;Безымянные&quot; C.A.S.S.I.E.</li>
              </ChangeList>
            </div>
          </Group>
          <Group title="18 Сентября">
            <div className="space-y-2">
              <ChangeList>
                <li>
                  Мы закончили полный редизайн, изменили шрифт, его цвет, его заливку в некоторых
                  случаях.
                </li>
                <li>Все C.A.S.S.I.E и Cinfo были рассортированы.</li>
                <li>
                  Раздел <span className="text-scp-orange">&quot;C.A.S.S.I.E | Раунд&quot;</span>{" "}
                  скрыт.
                </li>
                <li>Раздел &quot;Прочее&quot; переименован в &quot;Полезная информация&quot;.</li>
                <li>
                  Был написан полный гайд по ProjectMER в разделе &quot;Полезная информация&quot;.
                </li>
                <li>Добавлены ключ-карты авторства Dev1lMachine.</li>
              </ChangeList>
            </div>
          </Group>
          <Group title="11 Откября">
            <div className="space-y-2">
              <ChangeList>
                <li>Добавлен раздел &quot;История изменений&quot;.</li>
                <li>Добавлен раздел &quot;Предложения&quot;.</li>
                <li>
                  Добавлено пояснение для свойства Index в ProjectMER, и пояснение для
                  MEROptimizer.
                </li>
                <li>
                  Раздел &quot;C.A.S.S.I.E | Ивент&quot; переименован в{" "}
                  <span className="text-scp-orange">&quot;C.A.S.S.I.E&quot;</span>.
                </li>
              </ChangeList>
            </div>
          </Group>
          <Group title="18 Декабря">
            <div className="space-y-2">
              <ChangeList>
                <li>Все CASSIE переведены в новый формат.</li>
                <li>Добавлен небольшой гайд по Custom Info.</li>
                <li>Удалены Custom-Info, авторства ComicManatee926.</li>
              </ChangeList>
            </div>
          </Group>
        </div>
      </SeasonSection>

      {/* ── Зима 2025 - 2026 ───────────────────────────────────────── */}
      <SeasonSection title="Зима 2025 - 2026">
        <div className="space-y-4">
          <Group title="18 Декабря">
            <div className="space-y-2">
              <ChangeList>
                <li>Все CASSIE переведены в новый формат.</li>
                <li>Добавлен небольшой гайд по Custom Info.</li>
                <li>Удалены Custom-Info, авторства ComicManatee926.</li>
              </ChangeList>
            </div>
          </Group>
          <Group title="10 Января">
            <div className="space-y-2">
              <ChangeList>
                <li>
                  Заменены названия страниц:
                  <ul className="mt-2 space-y-1.5 pl-5 font-mono text-xs sm:text-sm text-zinc-400 border-l-2 border-zinc-800">
                    <li>
                      C.A.S.S.I.E - <span className="text-scp-orange">CASSIE</span>
                    </li>
                    <li>
                      CInfo - <span className="text-scp-orange">CINFO</span>
                    </li>
                    <li>
                      Полезная информация - <span className="text-scp-orange">INFORMATION</span>
                    </li>
                    <li>
                      Ключ-карты - <span className="text-scp-orange">KEYCARDS</span>
                    </li>
                    <li>
                      История изменений - <span className="text-scp-orange">HISTORY</span>
                    </li>
                  </ul>
                </li>
                <li>
                  Страницы &quot;Предложения&quot; и &quot;Список ивентов (устарел)&quot; были
                  удалены.
                </li>
                <li>Вновь изменен дизайн сайта.</li>
                <li>CASSIE, CINFO и Ключ-карты теперь копируются нажатием мыши.</li>
                <li>CASSIE для мини-ивентов были удалены</li>
                <li>
                  Переписана больша́я часть текста на странице INFORMATION, убран неактуальный блок
                  про MEROptimizer.
                </li>
              </ChangeList>
            </div>
          </Group>
        </div>
      </SeasonSection>

      {/* ── Весна 2026 ─────────────────────────────────────────────── */}
      <SeasonSection title="Весна 2026">
        <div className="space-y-4">
          <Group title="5 Апреля">
            <div className="space-y-2">
              <ChangeList>
                <li>Сайт полностью переписан на React.</li>
                <li>Вновь полностью обновлен дизайн.</li>
                <li>
                  Каждая страница частично переписана, страница c информацией частично урезана.
                </li>
              </ChangeList>
            </div>
          </Group>
          <Group title="8 Апреля">
            <div className="space-y-2">
              <ChangeList>
                <li>Вся запланированная информация была перенесена.</li>
                <li>
                  В custom-info и ключ-карты были добавлены поял для ввода id игроков.
                </li>
              </ChangeList>
            </div>
          </Group>
        </div>
      </SeasonSection>

      {/* ── Лето 2026 ──────────────────────────────────────────────── */}
      <SeasonSection title="Лето 2026">
        <div className="space-y-4">
          <Group title="29 Июня">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-[10px] font-mono uppercase tracking-widest text-zinc-500">
                <History className="w-3.5 h-3.5 text-scp-orange" />
                Текущий сезон
              </div>
              <ChangeList>
                <li>Добавлены Cinfo и ключ-карты от Burst173 и solosquad2008.</li>
                <li>Удалены Cinfo от Dev1lMachine и смешанные ключ-карты.</li>
                <li>Удалены старые Cinfo и ключ-карты от solosquad2008.</li>
                <li>
                  Частично улучшена совместимость с мобильными устройствами и мониторами, но их
                  использование крайне не рекомендуется из-за проблем на половине страниц.
                </li>
              </ChangeList>
            </div>
          </Group>
        </div>
      </SeasonSection>
    </div>
  );
}
