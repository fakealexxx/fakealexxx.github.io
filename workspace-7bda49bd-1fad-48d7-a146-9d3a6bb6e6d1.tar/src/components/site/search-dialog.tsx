"use client";

/**
 * Глобальный поиск по всем записям (Ctrl+K) — улучшение относительно оригинала.
 * Ищет по Cinfo, CASSIE и ключ-картам, показывает источник записи
 * и позволяет сразу скопировать код.
 */
import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { Copy, Check } from "lucide-react";
import { useDatabases } from "@/hooks/use-databases";
import { toast } from "sonner";
import type { Route } from "@/hooks/use-hash-route";

interface SearchDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onNavigate: (route: Route) => void;
}

export function SearchDialog({ open, onOpenChange, onNavigate }: SearchDialogProps) {
  const { allItems } = useDatabases();
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if ((e.key === "k" || e.key === "K" || e.key === "k".toUpperCase()) && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        onOpenChange(!open);
      }
    };
    document.addEventListener("keydown", down);
    return () => document.removeEventListener("keydown", down);
  }, [open, onOpenChange]);

  const grouped = useMemo(() => {
    return {
      "Custom-Info": allItems.filter((i) => i.section === "Custom-Info"),
      "C.A.S.S.I.E": allItems.filter((i) => i.section === "C.A.S.S.I.E"),
      "Ключ-карты": allItems.filter((i) => i.section === "Ключ-карты"),
    };
  }, [allItems]);

  const navigateFor = useCallback(
    (section: string): Route => {
      if (section === "C.A.S.S.I.E") return "/cassie";
      if (section === "Ключ-карты") return "/keycards";
      return "/cinfo";
    },
    []
  );

  const handleCopy = useCallback(async (id: string, code: string, name: string) => {
    try {
      await navigator.clipboard.writeText(code);
    } catch {
      /* игнорируем */
    }
    setCopiedId(id);
    toast.success("Скопировано", { description: name });
    setTimeout(() => setCopiedId(null), 2000);
  }, []);

  return (
    <CommandDialog open={open} onOpenChange={onOpenChange} className="border-zinc-800">
      <CommandInput placeholder="Поиск по всем записям терминала..." />
      <CommandList className="max-h-[60vh] custom-scrollbar">
        <CommandEmpty>Ничего не найдено.</CommandEmpty>
        {Object.entries(grouped).map(([section, items]) => (
          <CommandGroup
            key={section}
            heading={
              <span className="text-scp-orange font-black uppercase tracking-widest text-xs">{section}</span>
            }
          >
            {items.map((item, idx) => {
              const id = `${item.db}-${idx}`;
              return (
                <CommandItem
                  key={id}
                  value={`${item.name} ${item.group} ${item.subgroup}`}
                  onSelect={() => {
                    onOpenChange(false);
                    onNavigate(navigateFor(item.section));
                  }}
                  className="gap-2"
                >
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      void handleCopy(id, item.code, item.name);
                    }}
                    className="shrink-0 p-1.5 rounded border border-zinc-800 text-zinc-500 hover:text-scp-orange hover:border-scp-orange/40 transition-colors"
                    aria-label={`Скопировать: ${item.name}`}
                  >
                    {copiedId === id ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-bold text-zinc-200 truncate">{item.name}</div>
                    <div className="text-[10px] text-zinc-500 uppercase tracking-wider truncate">
                      {item.group}
                      {item.subgroup ? ` — ${item.subgroup}` : ""}
                    </div>
                  </div>
                  <span className="text-[9px] text-zinc-600 font-mono uppercase">{item.db}</span>
                </CommandItem>
              );
            })}
          </CommandGroup>
        ))}
      </CommandList>
    </CommandDialog>
  );
}
