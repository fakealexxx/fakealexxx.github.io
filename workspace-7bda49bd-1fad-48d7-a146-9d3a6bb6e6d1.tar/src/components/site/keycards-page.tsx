"use client";

/**
 * Страница Ключ-карт: кастомные модели + базы ключ-карт.
 */
import React from "react";
import { PageHeader, InfoSection, Code } from "./shared";
import { DatabaseSection } from "./database-section";
import { useTOC } from "./toc-context";
import { withBasePath } from "@/lib/base-path";

const keycardImages = [
  { src: "/images/keycard2.png", code: "keycardcustommetalcase" },
  { src: "/images/keycard3.png", code: "keycardcustommanagement" },
  { src: "/images/keycard4.png", code: "keycardcustomsite02" },
  { src: "/images/keycard5.png", code: "keycardcustomtaskforce" },
];

export function KeycardsPage() {
  useTOC(false);

  return (
    <div className="space-y-10 pb-24">
      <PageHeader
        title="Ключ-"
        highlight="карты"
        description="Настройка кастомных ключ-карт на сервере"
      />

      <InfoSection title="Кастомные модели" id="section-models">
        <div className="space-y-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            {keycardImages.map((img) => (
              <div
                key={img.code}
                className="bg-zinc-950/60 border border-zinc-900 rounded-xl p-4 flex flex-col items-center justify-between gap-4"
              >
                <div className="w-full h-32 flex items-center justify-center overflow-hidden rounded-lg bg-black/20">
                  <img
                    src={withBasePath(img.src)}
                    alt={`Ключ-карта ${img.code}`}
                    loading="lazy"
                    className="max-h-full object-contain transform hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="w-full text-center">
                  <p className="text-[10px] text-zinc-500 font-mono mb-1 uppercase tracking-wider">
                    ID Предмета:
                  </p>
                  <code className="text-xs font-mono text-scp-orange bg-zinc-900/80 px-2 py-1 rounded block break-all select-all">
                    {img.code}
                  </code>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-zinc-900/30 border border-zinc-800/60 rounded-xl p-4 sm:p-6 space-y-4">
            <h3
              data-toc="Важная информация"
              className="text-sm font-black uppercase tracking-widest text-white flex items-center gap-2"
            >
              <div className="w-1 h-3 bg-scp-orange" /> Важная информация
            </h3>
            <div className="text-zinc-400 text-xs sm:text-sm leading-relaxed">
              <ul className="list-disc list-outside pl-5 space-y-2">
                <li>
                  Все пробелы в названиях заменяются нижним подчёркиванием <Code>_</Code>.
                </li>
                <li>
                  Цвета ключ-карт настраиваются английскими названиями или цветом{" "}
                  <a
                    href="https://csscolor.ru/"
                    target="_blank"
                    rel="noreferrer"
                    className="underline text-scp-orange hover:text-white transition-colors"
                  >
                    HEX
                  </a>{" "}
                  (например, <span className="text-red-500 font-bold">#f00</span>).
                </li>
                <li>
                  Основная надпись и имя владельца выводятся на всех моделях, кроме{" "}
                  <Code>keycardcustommanagement</Code>.
                </li>
              </ul>
            </div>
          </div>
        </div>
      </InfoSection>

      <div className="border-b border-zinc-800" />

      <InfoSection title="Burst173" id="section-burst173">
        <p className="text-zinc-400 font-bold uppercase tracking-widest text-xs sm:text-sm border-l-2 border-scp-orange pl-4">
          Введите id игрока/игроков и используйте кнопку справа от текста для копирования
        </p>
        <DatabaseSection databaseName="keycards_burst173" />
      </InfoSection>

      <InfoSection title="SoloSquad2008" id="section-solosquad2008">
        <DatabaseSection databaseName="keycards_solosquad2008" />
      </InfoSection>
    </div>
  );
}
