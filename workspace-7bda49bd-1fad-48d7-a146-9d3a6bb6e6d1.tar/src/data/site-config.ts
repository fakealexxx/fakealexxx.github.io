/**
 * ============================================================
 *  НАСТРОЙКИ САЙТА — РЕДАКТИРУЙТЕ ЭТОТ ФАЙЛ ПОД СЕБЯ
 * ============================================================
 *  Здесь задаются: название сайта, имя автора, футер,
 *  дата последнего обновления и подключение Google Таблиц.
 *
 *  Данные (Cinfo / CASSIE / Ключ-карты) лежат в файле
 *  src/data/databases.json — их можно менять прямо там,
 *  либо подключить свою Google Таблицу (см. googleSheets ниже).
 * ============================================================
 */

export interface SiteConfig {
  /** Короткое название сайта (логотип в сайдбаре) */
  siteName: string;
  /** Подпись под названием (например "by Aphin") */
  siteAuthor: string;
  /** Заголовок вкладки браузера */
  title: string;
  /** Крупный заголовок на главной */
  heroTitleTop: string;
  /** Оранжевая часть заголовка на главной */
  heroTitleBottom: string;
  /** Описание на главной */
  heroDescription: string;
  /** Текст в футере слева */
  footerText: string;
  /** Текст в футере справа (год) */
  footerYear: string;
  /** Дата "Последнее обновление" в блоке статистики */
  lastUpdate: string;
  /**
   * Подключение внешних данных из опубликованной Google Таблицы.
   *
   * Как использовать СВОЮ таблицу:
   *  1. Создайте Google Таблицу с листами (можно переименовать ключи ниже).
   *  2. Файл -> Поделиться -> Опубликовать в интернете (весь документ).
   *  3. Из URL публикации скопируйте ключ 2PACX-... (см. docs.google.com/spreadsheets/d/e/КЛЮЧ/pub?...).
   *  4. Вставьте ключ и gid каждого листа ниже, поставьте enabled: true.
   *  5. Столбцы таблицы: group | subgroup | name | code
   *
   * Если enabled: false — сайт использует локальные данные из
   * файла src/data/databases.json (рекомендуется для GitHub Pages).
   */
  googleSheets: {
    enabled: boolean;
    spreadsheetKey: string;
    databases: {
      /** ключ базы данных (должен совпадать с ключами в databases.json) */
      database: string;
      /** gid листа из URL таблицы */
      gid: string;
    }[];
  };
}

export const SITE_CONFIG: SiteConfig = {
  siteName: "Events",
  siteAuthor: "by Aphin",
  title: "LITERY | Events",
  heroTitleTop: "Терминал",
  heroTitleBottom: "Ивент-мастера",
  heroDescription:
    "Используйте блоки ниже для быстрого поиска необходимой вам информации.",
  footerText: "Создано Aphin, при помощи mr wdy xiii",
  footerYear: "2025-2026",
  lastUpdate: "29.06.2026",
  googleSheets: {
    enabled: false,
    spreadsheetKey: "2PACX-1vR7eJDGzK_SPH_KqsCouWFO1XR7yN5begtpnEvYV8NNiaYP5BBXS6BcisJNuJ6nwKuRlcWegWGFMM-G",
    databases: [
      { database: "cinfo_aphin", gid: "1826825207" },
      { database: "cinfo_solosquad2008", gid: "715521451" },
      { database: "cassie_aphin", gid: "1593061573" },
      { database: "cassie_dev1lmachine", gid: "1924081634" },
      { database: "keycards_solosquad2008", gid: "2123056300" },
      { database: "cassie_burst173", gid: "2104192889" },
      { database: "cinfo_burst173", gid: "523095603" },
      { database: "keycards_burst173", gid: "1996752332" },
    ],
  },
};

/** Тип одной записи базы данных */
export interface DataItem {
  /** Название группы (аккордеон 1-го уровня) */
  group: string;
  /** Название подгруппы (аккордеон 2-го уровня) */
  subgroup: string;
  /** Название записи */
  name: string;
  /** Код / команда (поддерживает {{input:подсказка}} для полей ввода) */
  code: string;
}

/** Ключи всех баз данных */
export type DatabaseKey =
  | "cinfo_aphin"
  | "cinfo_solosquad2008"
  | "cassie_aphin"
  | "cassie_dev1lmachine"
  | "keycards_solosquad2008"
  | "cassie_burst173"
  | "cinfo_burst173"
  | "keycards_burst173";
