/**
 * Минимальный CSV-парсер (аналог papaparse) для загрузки
 * опубликованных Google Таблиц без внешних зависимостей.
 */
export function parseCSV(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        field += c;
      }
    } else if (c === '"') {
      inQuotes = true;
    } else if (c === ",") {
      row.push(field);
      field = "";
    } else if (c === "\n" || c === "\r") {
      if (c === "\r" && text[i + 1] === "\n") i++;
      row.push(field);
      field = "";
      if (row.length > 1 || row[0] !== "") rows.push(row);
      row = [];
    } else {
      field += c;
    }
  }
  if (field !== "" || row.length) {
    row.push(field);
    rows.push(row);
  }
  return rows;
}

export function csvToItems(text: string): { group: string; subgroup: string; name: string; code: string }[] {
  const rows = parseCSV(text);
  if (!rows.length) return [];
  rows.shift(); // заголовок group,subgroup,name,code
  return rows.map((r) => ({
    group: r[0] ?? "",
    subgroup: r[1] ?? "",
    name: r[2] ?? "",
    code: r[3] ?? "",
  }));
}
