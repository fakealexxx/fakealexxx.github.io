/**
 * Помощник для путей к статике — учитывает basePath на GitHub Pages
 * (когда сайт размещён в подкаталоге вида username.github.io/repo/).
 */
export const BASE_PATH = process.env.NEXT_PUBLIC_BASE_PATH ?? "";

export function withBasePath(path: string): string {
  if (!path.startsWith("/")) return path;
  return `${BASE_PATH}${path}`;
}
