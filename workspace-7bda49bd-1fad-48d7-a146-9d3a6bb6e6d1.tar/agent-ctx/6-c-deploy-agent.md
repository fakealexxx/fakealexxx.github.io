# Task 6-c — Деплой-пакет GitHub Pages

**Agent:** deploy-agent
**Date:** 2026 (сессия 6-c)
**Status:** ✅ completed

## Задача

Подготовить проект к развёртыванию на GitHub Pages: управляемый переменными
окружения статический экспорт, скрипт сборки, GitHub Actions workflow и
подробная инструкция для владельца сайта (не разработчика).

## Work Log

1. Прочитан `worklog.md` (контекст: SPA-терминал ивент-мастера SCP:SL,
   hash-роутинг, данные в `src/data/databases.json` + `site-config.ts`).
2. Изучены `next.config.ts`, `package.json`, `src/data/site-config.ts`,
   `src/data/databases.json`, `src/lib/base-path.ts`, `src/hooks/use-databases.ts`,
   `src/app/layout.tsx`, `.gitignore`.
3. **Верификация совместимости со статическим экспортом (по исходникам
   next 16.1.3 в node_modules):**
   - `src/app/api/route.ts` (демо GET-роут) при `output: "export"` вызывает
     ошибку E301 (`export const dynamic = "force-static" ... not configured`),
     т.к. не помечен как статический → сборка на GitHub упала бы.
   - `npm ci` и `actions/setup-node` c `cache: npm` требуют
     `package-lock.json`, которого в проекте нет (только `bun.lock`).
   - Сайт нигде не обращается к `/api` (grep по src — единственный fetch это
     Google Sheets в use-databases.ts), данные локального JSON бандлятся
     на этапе сборки → basePath для данных не нужен.
4. Изменён `next.config.ts`: при `DEPLOY_MODE=github` → `output: "export"`,
   `basePath`/`assetPrefix` из `NEXT_PUBLIC_BASE_PATH` (пустая → undefined),
   `images: { unoptimized: true }`, `trailingSlash: true`; иначе прежний
   конфиг (`standalone`). Dev-режим не затронут (проверено исполнением
   конфига в трёх режимах).
5. `package.json`: добавлен скрипт `"build:github": "next build"`
   (запускается workflow с `DEPLOY_MODE=github`); остальные скрипты не тронуты.
6. Создан `.github/workflows/deploy.yml`: push в main + workflow_dispatch,
   permissions (contents read / pages write / id-token write), concurrency
   group "pages", jobs build+deploy (checkout → setup-node 20 → npm ci ||
   npm install → rm src/app/api → вычисление basePath shell-скриптом →
   npm run build:github с env → upload-pages-artifact@v3 ./out →
   deploy-pages@v4, environment github-pages).
   - basePath считается отдельным shell-шагом из `$GITHUB_REPOSITORY`,
     т.к. inline-выражение `cond && '' || fallback` в GitHub Actions при
     пустомbasePath даёт неверный результат (классическая ловушка `||`).
7. Создан `README-GITHUB.md` — подробная русскоязычная инструкция
   (4 шага + локальный запуск + таблица частых ошибок).
8. Проверки: `package.json` — валидный JSON; `deploy.yml` — валидный YAML
   (js-yaml, структура совпадает с заданием); `next.config.ts` — исполнен в
   bun в режимах default/github/github+basePath, значения корректны;
   shell-логика basePath проверена на `aphin4/aphin4.github.io` (→ "") и
   `aphin4/events-terminal` (→ "/events-terminal").
9. `bun run build` / `lint` / `npm install` / dev-сервер не запускались
   (по ограничениям задачи).

## Решения и отклонения от ТЗ (важно)

- **`rm -rf src/app/api` в workflow вместо правки `src/app/api/route.ts`**
  (запрещённой ограничениями). Причина: демо-роут `/api` сайтом не
  используется, но ломает `output: "export"` (ошибка E301 в next 16.1.3).
  Удаление происходит только в CI, локально файл остаётся, dev-режим не страдает.
- **`npm ci || npm install` вместо чистого `npm ci`** и **отсутствует
  `cache: npm`** в setup-node: в репозитории нет `package-lock.json`
  (только `bun.lock`) — иначе workflow упал бы ещё на установке/кэше.
  В yaml оставлены комментарии: если позже закоммитить package-lock.json,
  можно включить `cache: "npm"`.
- `package.json` не позволяет комментариев — описание скрипта `build:github`
  вынесено в комментарии `next.config.ts`, workflow и README-GITHUB.md.
- `README.md` не тронут (по ТЗ), создан отдельный `README-GITHUB.md`.
- В README добавлены практические заметки для новичка: скрытые папки в
  macOS (Cmd+Shift+.), `git branch -M main` для workflow-триггера, включение
  Pages ПОСЛЕ первого пуша (Re-run workflow), косметическая особенность
  favicon в подкаталоге (метадата-иконка не получает basePath — в layout.tsx,
  который вне зоны правок).

## Изменённые/созданные файлы

- `next.config.ts` — изменён (dual-mode конфиг)
- `package.json` — изменён (+1 скрипт `build:github`)
- `.github/workflows/deploy.yml` — создан
- `README-GITHUB.md` — создан
- `agent-ctx/6-c-deploy-agent.md` — этот файл
- `worklog.md` — добавлена секция Task 6-c
