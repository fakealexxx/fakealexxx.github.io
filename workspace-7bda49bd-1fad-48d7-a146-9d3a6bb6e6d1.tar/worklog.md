# Worklog — копия сайта LITERY | Events (aphin4.github.io) на Next.js

---
Task ID: 1
Agent: main (Z.ai Code)
Task: Изучить оригинал, извлечь данные и ресурсы, создать основу проекта

Work Log:
- Склонирован оригинальный репозиторий github.com/Aphin4/aphin4.github.io в /tmp/aphin_repo
- Сайт — React SPA (Vite, Tailwind 4, framer-motion), hash-роутинг, данные грузятся из опубликованной Google Таблицы (8 листов CSV)
- Через agent-browser fetch получены все 8 CSV (625 записей) и распарсены в JSON
- Ресурсы скопированы в public/images/ (litery.png, keycard1-5.png, other1-3.png, toolgun.png)
- Созданы src/data/databases.json (625 записей) и src/data/site-config.ts (все настройки сайта, опция Google Sheets)
- Обновлены src/app/globals.css (SCP-тема: scp-orange #F5A671, scanline, glitch, crt-grid) и src/app/layout.tsx (Inter, метаданные, тосты sonner)
- Создано ядро: src/hooks/use-hash-route.ts, src/hooks/use-databases.ts, src/lib/csv.ts, src/lib/base-path.ts, src/components/site/toc-context.tsx
- Создан Layout: src/components/site/terminal-layout.tsx (сайдбар, мобильное меню, оглавление, прогресс чтения, футер, CRT-эффекты)
- Созданы общие компоненты: src/components/site/shared.tsx (InfoSection, InfoSectionCenter, Code, Group, PageHeader, CommandTable), accordion-copy.tsx (копирование, {{input:...}} поля, поиск внутри секций, раскрыть/свернуть всё), database-section.tsx
- Созданы страницы: home-page.tsx (карточки + анимированная статистика), cinfo-page.tsx, cassie-page.tsx, keycards-page.tsx, заготовки information-page.tsx и history-page.tsx
- Создан глобальный поиск Ctrl+K: src/components/site/search-dialog.tsx (по всем 625 записям с копированием)
- src/app/page.tsx — hash-роутер всех страниц
- Dev-сервер проверен: GET / 200, компиляция без ошибок

Stage Summary:
- Структура для субагентов:
  - Общие компоненты в src/components/site/shared.tsx: InfoSection({title, children, id?}), InfoSectionCenter({title, children, id?}), Code({children}), Group({title, children, header?, defaultOpen?}), PageHeader({title, highlight?, titleSuffix?, description}), CommandTable({rows:[{cmd,text}], colsFirst?})
  - InfoSection/InfoSectionCenter автоматически рендерят h2 с data-toc; Group рендерит h3 с data-toc (попадают в оглавление)
  - Изображения: withBasePath("/images/xxx.png") из "@/lib/base-path" (файлы в public/images/)
  - Стили: цвета text-scp-orange, bg-scp-bg, border-scp-border и т.д. доступны как tailwind-классы
  - Страницы-компоненты: 'use client', экспорт InformationPage / HistoryPage, используют useTOC(true) из "./toc-context"
  - Оригиналы контента: /tmp/aphin_repo/src/pages/Information.tsx и History.tsx

---
Task ID: 6-a
Agent: content-agent (Z.ai Code)
Task: Перенос страницы Information

Work Log:
- Прочитан worklog.md (договорённости Task 1) и исходник /tmp/aphin_repo/src/pages/Information.tsx целиком (533 строки)
- Изучены API общих компонентов: shared.tsx (PageHeader, InfoSectionCenter, InfoSection, Code, Group, CommandTable, colsFirst-карта статичных классов), toc-context.tsx, сборщик оглавления в terminal-layout.tsx (коллектит только h2[data-toc] и h3[data-toc])
- Полностью переписана заготовка src/components/site/information-page.tsx: 'use client', export function InformationPage(), useTOC(true)
- Весь контент оригинала сохранён: теги Custom-Info, примечания, 23 цвета, 4 ошибки консоли, ToolGun + управление, 2 типа построек, команды mp (карты — 4, схематики/объекты — 13, включая задублированный mp scale set), 12 объектов, все 12 таблиц свойств (примитив, свет, дверь, ItemSpawnpoint, Locker, Teleport, Workstation, TextToy, Scp079Camera, ShootingTarget, PlayerSpawnpoint, другие объекты), ccolor, intercomtext, 7 прочих команд, примеры cinfo с X/Check, ID классов (23 класса + 3 сокращения + 11 команд)
- Дубликат строки IsOpen в таблице двери сохранен как в оригинале (фиделити к исходнику)
- Локальные помощники в файле: Panel, PanelTitle (h3 + data-toc), Divider, CmdBlock, Val, PropertyTable (3-колоночная таблица свойств со статической PROP_COL_MAP 2-6-4 / 2-5-5 / 2-4-6 / 2-3-7 / 2-2-8 — без динамической конкатенации классов)
- Изображения через withBasePath: toolgun.png (ToolGun), other3.png (свойства примитива), other1.png (ccolor), other2.png (intercomtext); все с alt, loading="lazy", rounded-xl hover:scale-105 transition-transform max-w-full h-auto
- Команды mp mp mod/управление Тулганом/прочие команды вынесены в CommandTable (colsFirst 2/3/5) вместо ручных grid-cols-12
- Заголовки h3 помечены data-toc: Примечания, Цвет, Проблемы, ToolGun, Взаимодействие с картой и объектами, Свойства объектов, Свойства примитива, ..., Другие объекты, Кастомное освещение, Текст интеркома, Различные команды, Использование команд на множество игроков + Group «Id классов» — все попадают в оглавление
- Цветовые акценты: text-red-500 для предупреждений (заглавные буквы HEX, значения >100, мягкие тени, «Важно!»), text-green-500/красный-зеленый-синий для RGB-расшифровки ccolor, text-scp-orange для ключевых слов
- bun run build / lint / dev не запускались (по инструкции)

Stage Summary:
- src/components/site/information-page.tsx полностью выношен (≈900 строк): 3 больших секции InfoSectionCenter (Custom-Info / Строительство (ProjectMER) / Прочее), вложенные панели Panel с PanelTitle (h3, data-toc → оглавление)
- Использованы общие компоненты: PageHeader, InfoSectionCenter, Code, Group (Цвета — header=false defaultOpen; Id классов — header=true, закрыта по умолчанию), CommandTable (5 таблиц)
- Локальная PropertyTable для 3-колоночных таблиц свойств (свойство | описание | значения) со статической картой классов колонок
- 4 изображения подключены через withBasePath: /images/toolgun.png, /images/other1.png, /images/other2.png, /images/other3.png
- Списки данных вынесены в константы: CI_TAGS, CUSTOM_COLORS (23), MER_OBJECTS (12), CLASS_ROLES/CLASS_ABBREVS/CLASS_COMMANDS — рендерятся сетками с цветовыми свотчами и Code-чипами

---
Task ID: 6-b
Agent: History Content Agent (Z.ai Code)
Task: Перенос страницы History

Work Log:
- Прочитан worklog.md (договорённости, API shared-компонентов) и оригинал /tmp/aphin_repo/src/pages/History.tsx (204 строки)
- Проверено поведение Group в оригинальном Modules.tsx: группы свёрнуты по умолчанию (useState(false)) — поведение сохранено
- Полностью переписан /home/z/my-project/src/components/site/history-page.tsx: 'use client', export HistoryPage, useTOC(true) из './toc-context'
- Перенесён весь контент по сезонам: «Немного предыстории», «Последние изменения - 29.06.2026», «Лето 2025», «Осень 2025», «Зима 2025 - 2026», «Весна 2026», «Лето 2026»
- Даты-группы через Group: 8 Июня, 9 - 13 Июня, 21 - 23 Июня, 13 - 16 Июля, 2 Сентября, 7 Сентября, 18 Сентября, 11 Откября (опечатка оригинала сохранена), 18 Декабря (в Осени и в Зиме — дублирование как в оригинале), 10 Января, 5 Апреля, 8 Апреля, 29 Июня
- Локальные помощники оформления: ChangeList (list-disc с marker:text-scp-orange), Note (курсивные вставки с оранжевой левой чертой), SeasonSection (InfoSection + border-b разделитель)
- Текст сохранён дословно, включая опечатки («поял для ввода id игроков», «Больша́я» с ударением) и «18 Декабря» в двух сезонах; названия страниц в группе «10 Января» оформлены mono-списком с подсветкой новых названий
- Другие файлы проекта не изменялись; build/lint/dev-сервер не запускались

Stage Summary:
- src/components/site/history-page.tsx готов: журнал изменений из 7 секций-сезонов (h2 в оглавлении) и 13 сворачиваемых групп-дат (h3 в оглавлении)
- Использованы только общие компоненты PageHeader/InfoSection/Group из './shared'; все списки — list-disc, примечания курсивом (Note), важное — text-scp-orange
- Весь текст оригинала сохранён 1:1 (включая опечатки), поэтому файл — точная копия контента, только с улучшенным оформлением

---
Task ID: 6-c
Agent: deploy-agent
Task: Деплой-пакет GitHub Pages

Work Log:
- Прочитан контекст проекта; изучены next.config.ts, package.json, src/data/site-config.ts, src/data/databases.json, src/lib/base-path.ts, use-databases.ts, layout.tsx, .gitignore
- Верифицировано по исходникам next 16.1.3: демо-роут src/app/api/route.ts ломает output:"export" (ошибка E301 force-static); npm ci и setup-node cache:npm требуют package-lock.json, которого нет (только bun.lock); сайт нигде не вызывает /api
- next.config.ts переработан: DEPLOY_MODE=github -> output:"export" + basePath/assetPrefix из NEXT_PUBLIC_BASE_PATH (пусто -> undefined) + images.unoptimized + trailingSlash:true; иначе прежний standalone-конфиг; dev-режим не изменён
- package.json: добавлен скрипт "build:github": "next build" (остальные скрипты не тронуты)
- Создан .github/workflows/deploy.yml: push в main + workflow_dispatch; permissions contents:read/pages:write/id-token:write; concurrency group "pages" cancel-in-progress; jobs build (checkout -> setup-node 20 -> npm ci || npm install -> rm -rf src/app/api -> shell-шаг вычисления basePath из GITHUB_REPOSITORY -> npm run build:github c env DEPLOY_MODE=github и NEXT_PUBLIC_BASE_PATH -> upload-pages-artifact@v3 ./out) и deploy (needs build, environment github-pages, deploy-pages@v4)
- basePath считается отдельным shell-шагом (inline-выражение cond && '' || x в GitHub Actions даёт неверный результат при пустом basePath); логика проверена: aphin4/aphin4.github.io -> "", aphin4/events-terminal -> "/events-terminal"
- Создан README-GITHUB.md: описание сайта, 2 варианта имени репозитория, загрузка кода (веб-интерфейс + git), включение Pages (Source: GitHub Actions), правка site-config.ts (таблица всех полей), формат databases.json (8 ключей, {group, subgroup, name, code}, {{input:...}}), Google Таблицы, замена картинок, локальный запуск, таблица частых ошибок
- Проверки без запуска сборок: package.json и deploy.yml — валидны (JSON.parse / js-yaml); next.config.ts исполнен в 3 режимах (default / github / github+basePath) — значения корректны; bun run build/lint, npm install, dev-сервер не запускались (по ограничениям)
- Полный отчёт агента: agent-ctx/6-c-deploy-agent.md

Stage Summary:
- Проект готов к публикации на GitHub Pages «из коробки»: владелец заливает код, включает Settings -> Pages -> Source: GitHub Actions — при каждом пуше в main сайт автоматически собирается статикой и публикуется
- Ключевое решение 1: API-роут src/app/api несовместим со статическим экспортом, но его правка запрещена ТЗ -> workflow удаляет его перед сборкой (rm -rf src/app/api), локально файл остаётся, dev не страдает
- Ключевое решение 2: npm ci || npm install и без cache:npm (нет package-lock.json, только bun.lock) — иначе workflow падал на установке
- Режимы next.config.ts: обычный (standalone, без изменений) vs DEPLOY_MODE=github (export + basePath); basePath вычисляется автоматически: репозиторий <username>.github.io -> корень, иначе -> /<имя-репо>
- Для владельца: инструкция README-GITHUB.md (4 шага + частые ошибки); данные редактируются прямо на GitHub (site-config.ts, databases.json) — коммит в main пересобирает сайт автоматически

---
Task ID: 7-8
Agent: main (Z.ai Code)
Task: Финальная интеграция, исправления, сквозная верификация

Work Log:
- Удалён демо API-роут src/app/api (не использовался сайтом; ломал статический экспорт) — из .github/workflows/deploy.yml убран шаг rm -rf src/app/api
- Исправлена ошибка линтера react-hooks/set-state-in-effect: use-hash-route.ts переписан на useSyncExternalStore; use-databases.ts — локальный JSON инициализируется в useState-инициализаторе; terminal-layout.tsx — закрытие мобильного меню через hashchange-листенер, сбор TOC через setTimeout, прогресс через requestAnimationFrame
- Удалены неиспользуемые eslint-disable комментарии (information-page, keycards-page)
- Исправлен баг StatCard: дата «29.06.2026» анимировалась как число (счётчик до 29) — теперь анимируются только /^\d+$/ значения
- Исправлены дубликаты ключей в search-dialog (записи с одинаковыми name): ключ = `${db}-${idx}`
- Убран slice(0,12) в поиске — cmdk ищет по всем 625 записям
- bun run lint — 0 ошибок
- Верификация agent-browser: главная, /cinfo (копирование cinfo 777 <...> с подстановкой ID работает), /cassie (группы раскрываются), /keycards (картинки моделей + базы), /information (оглавление в сайдбаре), /history; Ctrl+K поиск, поиск внутри секций (фильтр 34→2), мобильная версия 390px (меню, оверлей), футер прилипает к низу (footerBottom=900=viewportH), на длинных страницах отодвигается контентом (3101→836 при скролле)
- Консоль браузера чистая: 0 ошибок на всех страницах

Stage Summary:
- Проект полностью готов: копия сайта LITERY | Events на Next.js 16 с улучшенным дизайном (CRT-эффекты, глобальный поиск Ctrl+K, поиск в секциях, тосты, анимированная статистика, прогресс чтения)
- Деплой на GitHub Pages: .github/workflows/deploy.yml + README-GITHUB.md; данные правятся через GitHub web UI (src/data/site-config.ts, src/data/databases.json)
