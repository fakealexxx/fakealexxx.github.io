import type { NextConfig } from "next";

/**
 * ============================================================
 *  Конфигурация Next.js — два режима работы
 * ============================================================
 *
 *  1. Обычный режим (по умолчанию) — разработка и запуск
 *     в этом окружении (`bun run dev` / `bun run build`).
 *     Работает ровно как раньше.
 *
 *  2. Режим GitHub Pages — включается автоматически, когда задана
 *     переменная окружения DEPLOY_MODE=github (её выставляет
 *     .github/workflows/deploy.yml перед запуском `npm run build:github`).
 *     В этом режиме сайт собирается в набор статических файлов
 *     в папку ./out, пригодный для хостинга на GitHub Pages.
 *
 *     NEXT_PUBLIC_BASE_PATH — префикс путей к статике:
 *       • пустой / не задан  -> сайт лежит в корне (username.github.io)
 *       • "/имя-репозитория" -> сайт лежит в подкаталоге
 *                               (username.github.io/имя-репозитория/)
 *     Значение вычисляется автоматически в workflow из имени репозитория.
 * ============================================================
 */
const isGithubDeploy = process.env.DEPLOY_MODE === "github";

const nextConfig: NextConfig = isGithubDeploy
  ? {
      // Статический экспорт: результат сборки появится в папке ./out
      output: "export",
      // Префикс путей (нужен, когда сайт публикуется не в корне домена)
      basePath: process.env.NEXT_PUBLIC_BASE_PATH || undefined,
      assetPrefix: process.env.NEXT_PUBLIC_BASE_PATH || undefined,
      // На GitHub Pages нет сервера оптимизации картинок — отключаем
      images: { unoptimized: true },
      // Ссылки вида "/раздел/" — корректное поведение на статическом хостинге
      trailingSlash: true,
      typescript: {
        ignoreBuildErrors: true,
      },
      reactStrictMode: false,
    }
  : {
      output: "standalone",
      typescript: {
        ignoreBuildErrors: true,
      },
      reactStrictMode: false,
    };

export default nextConfig;
